import { execFileSync, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const output = fileURLToPath(new URL('.', import.meta.url));
const source = 'src/ecs.ts';
const harness = 'tooling/suites/benchmarks/cpu/benchmark.ts';
const baseline = execFileSync('git', ['show', 'HEAD:src/ecs.ts'], { encoding: 'utf8' });
const candidate = readFileSync(source, 'utf8');
const hash = value => createHash('sha256').update(value).digest('hex');
const metadata = {
    date: new Date().toISOString(),
    baselineRevision: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
    baselineSourceSha256: hash(baseline),
    candidateSourceSha256: hash(candidate),
    harnessSha256: hash(readFileSync(harness)),
    method: 'Three fresh-process pairs, alternating baseline/candidate order. Identical harness and workload. Source restored in finally. No retries or outlier removal. Raw batch sums retained; summaries are per tick. No allocation profiler or browser measurement.',
    order: ['baseline-1', 'candidate-1', 'candidate-2', 'baseline-2', 'baseline-3', 'candidate-3'],
    command: 'node node_modules/tsx/dist/cli.mjs tooling/suites/benchmarks/cpu/benchmark.ts',
    runs: [],
};
writeFileSync(join(output, 'candidate.patch'), execFileSync('git', ['diff', '--', source]));
writeFileSync(join(output, 'harness.patch'), execFileSync('git', ['diff', '--', harness]));
writeFileSync(join(output, 'benchmark.ts'), readFileSync(harness));
try {
    for (const label of metadata.order) {
        writeFileSync(source, label.startsWith('baseline') ? baseline : candidate);
        const result = spawnSync(process.execPath, ['node_modules/tsx/dist/cli.mjs', harness], {
            encoding: 'utf8', maxBuffer: 16 * 1024 * 1024,
        });
        writeFileSync(join(output, `${label}.json`), result.stdout ?? '');
        writeFileSync(join(output, `${label}.stderr.txt`), result.stderr ?? '');
        metadata.runs.push({ label, status: result.status, error: result.error?.message });
        writeFileSync(join(output, 'comparison.json'), JSON.stringify(metadata, null, 2));
        if (result.status !== 0) throw new Error(`${label} failed; preserved output, no retry`);
        const data = JSON.parse(result.stdout);
        const small = data.manySmallQueries;
        console.log(JSON.stringify({ label, first: small.firstTraversalAfterCommitMs.p50,
            second: small.secondTraversalSameEpochMs.p50, commit: small.noOpCommitMs.p50,
            tick: small.simulatedTickMs.p50, resolution: small.timerResolutionMs }));
    }
} finally {
    writeFileSync(source, candidate);
}
