# verification

Run: 2026-09-30T15-05-52.843Z-verification-d6f3ea07-0b74-460d-ba61-eb563b0fe4d6
Accepted: false

- scenario: tests: exit 5; see C:\Users\jfabi\Documents\Projects\tests\ngne\out\runs\2026-09-30T15-05-52.843Z-verification-d6f3ea07-0b74-460d-ba61-eb563b0fe4d6\evidence\stages\tests\logs\command.log

Execution: failed; correctness: failed; budgets: not evaluated; cleanup: passed; evidence: complete.

Evidence applies only to the selected suite and recorded environment. It does not establish controlled run comparability or manual visual/audio confirmation. Compatibility was not selected.

- format: completed, correctness passed, budgets not evaluated
- tests: failed, correctness failed, budgets not evaluated

[Manifest](manifest.json) · [Result](result.json)
