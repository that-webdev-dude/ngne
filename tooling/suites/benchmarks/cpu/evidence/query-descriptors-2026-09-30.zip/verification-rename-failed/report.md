# verification

Run: 2026-09-30T15-03-23.179Z-verification-5e60892c-46cf-4fb5-bf1e-71f8d8dddb62
Accepted: false

- scenario: tests: exit 1; see C:\Users\jfabi\Documents\Projects\tests\ngne\out\runs\2026-09-30T15-03-23.179Z-verification-5e60892c-46cf-4fb5-bf1e-71f8d8dddb62\evidence\stages\tests\logs\command.log

Execution: failed; correctness: failed; budgets: not evaluated; cleanup: passed; evidence: complete.

Evidence applies only to the selected suite and recorded environment. It does not establish controlled run comparability or manual visual/audio confirmation. Compatibility was not selected.

- format: completed, correctness passed, budgets not evaluated
- tests: failed, correctness failed, budgets not evaluated

[Manifest](manifest.json) · [Result](result.json)
