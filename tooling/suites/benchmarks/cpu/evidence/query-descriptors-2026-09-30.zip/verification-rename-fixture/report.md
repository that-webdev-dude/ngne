# verification

Run: 2026-09-30T15-03-29.064Z-verification-23579928-f403-4286-994b-70c3e9943bac
Accepted: false

- scenario: EPERM: operation not permitted, rename 'C:\Users\jfabi\Documents\Projects\tests\ngne\.test-output\verification-composition\fixture-Baws4k\out\runs\2026-09-30T15-03-29.064Z-verification-23579928-f403-4286-994b-70c3e9943bac\evidence\result.json.8a17937d-a566-4124-91e0-2bf4b1c0be68.tmp' -> 'C:\Users\jfabi\Documents\Projects\tests\ngne\.test-output\verification-composition\fixture-Baws4k\out\runs\2026-09-30T15-03-29.064Z-verification-23579928-f403-4286-994b-70c3e9943bac\evidence\result.json'

Execution: failed; correctness: not evaluated; budgets: not evaluated; cleanup: passed; evidence: complete.

Evidence applies only to the selected suite and recorded environment. It does not establish controlled run comparability or manual visual/audio confirmation. Compatibility was not selected.

- format: completed, correctness passed, budgets not evaluated
- tests: completed, correctness passed, budgets not evaluated
- tooling-types: completed, correctness passed, budgets not evaluated
- types: completed, correctness passed, budgets not evaluated
- build: completed, correctness passed, budgets not evaluated
- browser-build: completed, correctness passed, budgets not evaluated
- prepare: completed, correctness passed, budgets not evaluated
- prepared: completed, correctness passed, budgets not evaluated
- transport: completed, correctness passed, budgets not evaluated
- installed: running, correctness not evaluated, budgets not evaluated

[Manifest](manifest.json) · [Result](result.json)
