# verification

Run: 2026-09-30T15-00-01.746Z-verification-41a12715-9ae5-4bde-a130-f526e01589c2
Accepted: false

- scenario: tests: command timeout
- cleanup: format terminate/verify: format PID 3696: terminate/verify failed: Command failed: powershell.exe -NoProfile -NonInteractive -Command Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,@{Name='Born';Expression={$_.CreationDate.ToUniversalTime().ToString('o')}} | ConvertTo-Json -Compress
Get-CimInstance : Access denied 
At line:1 char:1
+ Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcess ...
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : PermissionDenied: (root\cimv2:Win32_Process:String) [Get-CimInstance], CimException
    + FullyQualifiedErrorId : HRESULT 0x80041003,Microsoft.Management.Infrastructure.CimCmdlets.GetCimInstanceCommand
 

- cleanup: tests terminate/verify: tests PID 19904: terminate/verify failed: Command failed: powershell.exe -NoProfile -NonInteractive -Command Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,@{Name='Born';Expression={$_.CreationDate.ToUniversalTime().ToString('o')}} | ConvertTo-Json -Compress
Get-CimInstance : Access denied 
At line:1 char:1
+ Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcess ...
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : PermissionDenied: (root\cimv2:Win32_Process:String) [Get-CimInstance], CimException
    + FullyQualifiedErrorId : HRESULT 0x80041003,Microsoft.Management.Infrastructure.CimCmdlets.GetCimInstanceCommand
 


Execution: failed; correctness: failed; budgets: not evaluated; cleanup: failed; evidence: complete.

Evidence applies only to the selected suite and recorded environment. It does not establish controlled run comparability or manual visual/audio confirmation. Compatibility was not selected.

- format: completed, correctness passed, budgets not evaluated
- tests: failed, correctness failed, budgets not evaluated

[Manifest](manifest.json) · [Result](result.json)
