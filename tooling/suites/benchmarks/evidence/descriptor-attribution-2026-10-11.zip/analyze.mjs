import {readFileSync,writeFileSync} from 'node:fs';
const dir=new URL('./',import.meta.url);const read=n=>JSON.parse(readFileSync(new URL(n,dir),'utf8'));
const summary={timing:[],cpu:[],heap:[]};
function stats(a){const b=[...a].sort((a,b)=>a-b);return {p50:b[Math.floor(b.length*.5)],p95:b[Math.floor(b.length*.95)],mean:a.reduce((x,y)=>x+y,0)/a.length};}
for(const name of ['clean-tsx-1','clean-tsx-2','clean-tsx-3','clean-native-1']){const r=read(name+'.json');for(const w of r.workloads){const batch=[];for(let i=0;i<w.samples.length;i+=w.batchesPerEstablishedSample){const b=w.samples.slice(i,i+w.batchesPerEstablishedSample);batch.push([0,1,2].map(c=>b.reduce((sum,r)=>sum+r[c],0)/b.length));}summary.timing.push({name,workload:w.workload,commit:stats(batch.map(r=>r[0])),first:stats(batch.map(r=>r[1])),sameEpoch:stats(batch.map(r=>r[2])),delta:stats(batch.map(r=>r[1]-r[2]))});}}
for(const w of ['density','small']){
 const p=read(`cpu-${w}-${w}.cpuprofile`),r=read(`cpu-${w}.json`).workloads[0];const nodes=new Map(p.nodes.map(n=>[n.id,n]));const weights=new Map();for(let i=0;i<p.samples.length;i++)weights.set(p.samples[i],(weights.get(p.samples[i])??0)+p.timeDeltas[i]);
 const self=p.nodes.map(n=>({function:n.callFrame.functionName,line:n.callFrame.lineNumber+1,url:n.callFrame.url,hits:n.hitCount,ms:(weights.get(n.id)??0)/1000,ticks:n.positionTicks})).filter(n=>n.ms).sort((a,b)=>b.ms-a.ms);
 const lines=new Map();for(const n of p.nodes.filter(n=>n.callFrame.url.endsWith('/src/ecs.ts')))for(const t of n.positionTicks??[])lines.set(t.line,(lines.get(t.line)??0)+t.ticks);
 const source=readFileSync(new URL(`cpu-${w}-executed-ecs.js`,dir),'utf8').split('\n');
 summary.cpu.push({workload:w,elapsed:r.elapsed,iterations:r.iterations,sampleCount:p.samples.length,totalSampleMs:[...weights.values()].reduce((a,b)=>a+b,0)/1000,descriptorBuilderWeightedSampleMs:p.nodes.filter(n=>n.callFrame.functionName==='createChunkDescriptor').reduce((sum,n)=>sum+(weights.get(n.id)??0),0)/1000,self:self.slice(0,18),selfListNote:'Top 18 nodes only; descriptorBuilderWeightedSampleMs aggregates every matching raw profile node.',sourceLines:[...lines].map(([line,ticks])=>({line,ticks,source:source[line-1]})).sort((a,b)=>b.ticks-a.ticks).slice(0,30),gc:{count:r.gc.length,total:r.gc.reduce((a,b)=>a+b.duration,0),kinds:[...new Set(r.gc.map(e=>e.detail.kind))]}});
 const hp=read(`heap-${w}-${w}.heapprofile`),hr=read(`heap-${w}.json`).workloads[0];let total=0;const flat=[];
 function walk(n,path=[]){total+=n.selfSize;const next=[...path,`${n.callFrame.functionName}:${n.callFrame.lineNumber+1}`];let inclusive=n.selfSize;for(const c of n.children)inclusive+=walk(c,next);flat.push({function:n.callFrame.functionName,line:n.callFrame.lineNumber+1,url:n.callFrame.url,selfSize:n.selfSize,inclusive,path:next});return inclusive;}
 walk(hp.head);summary.heap.push({workload:w,totalSampledBytes:total,sampleCount:hp.samples.length,expectedDescriptors:hr.expectedDescriptorBuilds,bytesPerExpectedDescriptor:total/hr.expectedDescriptorBuilds,top:flat.sort((a,b)=>b.selfSize-a.selfSize).slice(0,15),elapsed:hr.elapsed,gc:{count:hr.gc.length,total:hr.gc.reduce((a,b)=>a+b.duration,0)}});
}
writeFileSync(new URL('profile-analysis.json',dir),JSON.stringify(summary,null,2));
console.log(JSON.stringify(summary,null,2));
