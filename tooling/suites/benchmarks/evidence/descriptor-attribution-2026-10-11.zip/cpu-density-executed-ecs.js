const CHUNK_CAPACITY = 512;
const FIELD_VALUE = Symbol("field value");
const SCHEMA_COMPONENT = Symbol("schema component");
function field(kind, defaultValue) {
    return Object.freeze({
        kind,
        default: defaultValue,
        [FIELD_VALUE]: defaultValue
    });
}
export const f32 = (defaultValue = 0)=>field("f32", validateF32("f32", defaultValue));
export const f64 = (defaultValue = 0)=>field("f64", validateNumber("f64", defaultValue));
export const i32 = (defaultValue = 0)=>field("i32", validateInteger("i32", defaultValue, -0x80000000, 0x7fffffff));
export const u32 = (defaultValue = 0)=>field("u32", validateInteger("u32", defaultValue, 0, 0xffffffff));
export const u8 = (defaultValue = 0)=>field("u8", validateInteger("u8", defaultValue, 0, 0xff));
export const bool = (defaultValue = false)=>{
    if (typeof defaultValue !== "boolean") throw new Error("Invalid bool default");
    return field("bool", defaultValue);
};
export function entityRef(...defaultValues) {
    if (defaultValues.length > 0) throw new Error("Entity reference defaults are always null");
    return field("entity", null);
}
export class SchemaComponent {
    name;
    [SCHEMA_COMPONENT] = true;
    fields;
    constructor(name, fields){
        this.name = name;
        if (!name) throw new Error("Component name required");
        if (typeof fields !== "object" || fields === null) throw new Error(`Component fields must be a schema object: ${name}`);
        const cloned = Object.create(null);
        for (const [fieldName, descriptor] of Object.entries(fields)){
            if (!fieldName) throw new Error("Component field name required");
            if (!isFieldDescriptor(descriptor)) throw new Error(`Invalid field descriptor: ${name}.${fieldName}`);
            const defaultValue = validateDescriptorDefault(`${name}.${fieldName}`, descriptor);
            cloned[fieldName] = Object.freeze({
                kind: descriptor.kind,
                default: defaultValue,
                [FIELD_VALUE]: defaultValue
            });
        }
        this.fields = Object.freeze(cloned);
        Object.freeze(this);
    }
    of(value = {}) {
        for (const fieldName of Object.keys(value))if (!(fieldName in this.fields)) throw new Error(`Unknown component field: ${this.name}.${fieldName}`);
        return {
            component: this,
            value
        };
    }
}
export function component(name, fields) {
    return new SchemaComponent(name, fields);
}
// Definitions and their fields are immutable. Keep iteration metadata private and
// weakly owned so repeated spawns do not enumerate the same schema or retain it.
const schemaFieldEntries = new WeakMap();
function fieldsOf(type) {
    let fields = schemaFieldEntries.get(type);
    if (!fields) {
        fields = Object.entries(type.fields);
        schemaFieldEntries.set(type, fields);
    }
    return fields;
}
class AllQueryRuntime {
    #world;
    constructor(world){
        this.#world = world;
        Object.freeze(this);
    }
    get size() {
        return this.#world.size;
    }
    each(visit) {
        this.#world.beginRead();
        try {
            for (const archetype of this.#world.archetypeList)for (const chunk of archetype.chunks)for(let row = 0; row < chunk.count; row++)visit(chunk.entities[row]);
        } finally{
            this.#world.endRead();
        }
    }
}
class SchemaQueryRuntime {
    #version = -1;
    #matches = [];
    #borrowEpoch = -1;
    #descriptors = [];
    #world;
    #types;
    constructor(world, types){
        this.#world = world;
        this.#types = types;
        Object.freeze(this);
    }
    get size() {
        this.refresh();
        return this.#matches.reduce((size, archetype)=>size + archetype.chunks.reduce((rows, chunk)=>rows + chunk.count, 0), 0);
    }
    eachChunk(visit) {
        this.refresh();
        this.refreshDescriptors();
        this.#world.beginRead();
        try {
            for (const descriptor of this.#descriptors)if (descriptor.count > 0) visit(descriptor);
        } finally{
            this.#world.endRead();
        }
    }
    refresh() {
        if (this.#version === this.#world.structureVersion) return;
        this.#matches = this.#world.archetypeList.filter((archetype)=>this.#types.every((type)=>archetype.types.includes(type)));
        this.#version = this.#world.structureVersion;
        this.#borrowEpoch = -1;
    }
    refreshDescriptors() {
        if (this.#borrowEpoch === this.#world.commitEpoch) return;
        const epoch = this.#world.commitEpoch;
        this.#descriptors = this.#matches.flatMap((archetype)=>archetype.chunks.map((chunk)=>createChunkDescriptor(this.#world, epoch, archetype, chunk, this.#types)));
        this.#borrowEpoch = epoch;
    }
}
Object.freeze(AllQueryRuntime.prototype);
Object.freeze(SchemaQueryRuntime.prototype);
class WorldAccessRuntime {
    #world;
    constructor(world){
        this.#world = world;
        defineOpaque(this, {
            spawn: this.spawn.bind(this),
            despawn: this.despawn.bind(this),
            has: this.has.bind(this),
            read: this.read.bind(this),
            write: this.write.bind(this),
            query: this.query.bind(this)
        });
    }
    spawn(...values) {
        return this.#world.spawnValues(values);
    }
    despawn(entity) {
        this.#world.despawn(entity);
    }
    has(entity) {
        return this.#world.has(entity);
    }
    read(entity, type, field) {
        return this.#world.read(entity, type, field);
    }
    write(entity, type, field, value) {
        this.#world.write(entity, type, field, value);
    }
    query(...types) {
        return this.#world.queryTypes(types);
    }
}
Object.freeze(WorldAccessRuntime.prototype);
export class World {
    owner = Symbol("world");
    slots = [];
    free = [];
    archetypes = [];
    births = [];
    deaths = new Set();
    definitions = new Map();
    reading = 0;
    disposed = false;
    structuralVersion = 0;
    epoch = 0;
    access;
    constructor(){
        this.access = new WorldAccessRuntime(this);
    }
    get archetypeList() {
        return this.archetypes;
    }
    get structureVersion() {
        return this.structuralVersion;
    }
    get commitEpoch() {
        return this.epoch;
    }
    get size() {
        return this.archetypes.reduce((size, archetype)=>size + archetype.chunks.reduce((rows, chunk)=>rows + chunk.count, 0), 0);
    }
    get capacity() {
        return this.slots.length;
    }
    beginRead() {
        this.reading++;
    }
    endRead() {
        this.reading--;
    }
    spawn(...values) {
        return this.spawnValues(values);
    }
    spawnValues(values) {
        if (this.disposed) throw new Error("World is disposed");
        for (const { component: type } of values)if (!isSchemaComponent(type)) throw new Error("Schema component required");
        if (new Set(values.map((value)=>value.component)).size !== values.length) throw new Error("Duplicate component");
        const lowered = values.map(({ component: type, value })=>({
                component: type,
                value: this.lowerSchemaValue(type, value)
            }));
        for (const { component: type } of values)this.registerDefinition(type);
        const index = this.free.pop() ?? this.slots.length;
        const slot = this.slots[index] ?? {
            generation: 0,
            chunk: -1,
            row: -1,
            pending: true
        };
        slot.pending = true;
        this.slots[index] = slot;
        const entity = Object.freeze({
            index,
            generation: slot.generation,
            owner: this.owner
        });
        slot.handle = entity;
        this.births.push({
            entity,
            values: lowered
        });
        return entity;
    }
    registerDefinition(type) {
        const existing = this.definitions.get(type.name);
        if (existing && existing !== type) throw new Error(`Conflicting component identity: ${type.name}`);
        this.definitions.set(type.name, type);
    }
    lowerSchemaValue(type, partial) {
        const value = Object.create(null);
        for (const fieldName of Object.keys(partial))if (!(fieldName in type.fields)) throw new Error(`Unknown component field: ${type.name}.${fieldName}`);
        for (const [fieldName, descriptor] of fieldsOf(type)){
            const candidate = Object.prototype.hasOwnProperty.call(partial, fieldName) ? Reflect.get(partial, fieldName) : undefined;
            const authored = candidate === undefined ? descriptor.default : candidate;
            value[fieldName] = this.validateField(type, fieldName, descriptor, authored);
        }
        return value;
    }
    validateField(type, fieldName, descriptor, value) {
        const label = `${type.name}.${fieldName}`;
        switch(descriptor.kind){
            case "f32":
                return validateF32(label, value);
            case "f64":
                return validateNumber(label, value);
            case "i32":
                return validateInteger(label, value, -0x80000000, 0x7fffffff);
            case "u32":
                return validateInteger(label, value, 0, 0xffffffff);
            case "u8":
                return validateInteger(label, value, 0, 0xff);
            case "bool":
                if (typeof value !== "boolean") throw new Error(`Invalid boolean: ${label}`);
                return value;
            case "entity":
                if (value === null) return null;
                if (!isEntity(value)) throw new Error(`Invalid entity reference: ${label}`);
                if (value.owner !== this.owner) throw new Error(`Foreign entity reference: ${label}`);
                const slot = this.slots[value.index];
                if (!slot || value.generation > slot.generation || value.generation === slot.generation && !slot.archetype && !slot.pending) throw new Error(`Unknown entity reference: ${label}`);
                if (value.index + 1 > 0xffffffff || value.generation > 0xffffffff) throw new Error(`Entity reference exceeds uint32 storage: ${label}`);
                return value;
        }
    }
    slot(entity) {
        const slot = this.slots[entity.index];
        return entity.owner === this.owner && slot?.generation === entity.generation ? slot : undefined;
    }
    has(entity) {
        return !!this.slot(entity)?.archetype;
    }
    read(entity, type, fieldName) {
        const descriptor = this.requireField(type, fieldName);
        const slot = this.slot(entity);
        if (!slot?.archetype) return undefined;
        const typeIndex = slot.archetype.types.indexOf(type);
        if (typeIndex < 0) return undefined;
        const column = slot.archetype.chunks[slot.chunk].columns[typeIndex][String(fieldName)];
        return this.readColumn(column, descriptor, slot.row);
    }
    write(entity, type, fieldName, value) {
        const descriptor = this.requireField(type, fieldName);
        const validated = this.validateField(type, String(fieldName), descriptor, value);
        const slot = this.slot(entity);
        if (!slot?.archetype) return;
        const typeIndex = slot.archetype.types.indexOf(type);
        if (typeIndex < 0) return;
        writeColumn(slot.archetype.chunks[slot.chunk].columns[typeIndex][String(fieldName)], descriptor.kind, slot.row, validated);
    }
    requireField(type, fieldName) {
        if (!isSchemaComponent(type)) throw new Error("Schema component required");
        const descriptor = type.fields[String(fieldName)];
        if (!descriptor) throw new Error(`Unknown component field: ${type.name}.${String(fieldName)}`);
        return descriptor;
    }
    readColumn(column, descriptor, row) {
        if (descriptor.kind === "entity") {
            const reference = column, encodedIndex = reference.index[row];
            if (encodedIndex === 0) return null;
            const index = encodedIndex - 1, generation = reference.generation[row], slot = this.slots[index];
            if (slot?.handle?.generation === generation) return slot.handle;
            return Object.freeze({
                index,
                generation,
                owner: this.owner
            });
        }
        const encoded = column[row];
        return descriptor.kind === "bool" ? encoded !== 0 : encoded;
    }
    despawn(entity) {
        const slot = this.slot(entity);
        if (slot && (slot.archetype || slot.pending)) this.deaths.add(entity);
    }
    query(...types) {
        return this.queryTypes(types);
    }
    queryTypes(types) {
        if (this.disposed) throw new Error("World is disposed");
        if (types.length === 0) return new AllQueryRuntime(this);
        if (!types.every(isSchemaComponent)) throw new Error("Schema component required");
        if (new Set(types).size !== types.length) throw new Error("Duplicate component");
        for (const type of types)this.registerDefinition(type);
        return new SchemaQueryRuntime(this, types);
    }
    commit() {
        if (this.reading) throw new Error("Cannot commit during query iteration");
        if (this.disposed) throw new Error("World is disposed");
        this.epoch++;
        for (const birth of this.births)this.commitBirth(birth);
        this.births.length = 0;
        for (const entity of this.deaths)this.commitDeath(entity);
        this.deaths.clear();
    }
    commitBirth(birth) {
        let archetype = this.archetypes.find((candidate)=>candidate.types.length === birth.values.length && birth.values.every((value)=>candidate.types.includes(value.component)));
        if (!archetype) {
            archetype = {
                types: birth.values.map((value)=>value.component),
                chunks: []
            };
            this.archetypes.push(archetype);
            this.structuralVersion++;
        }
        let chunkIndex = archetype.chunks.findIndex((chunk)=>chunk.count < CHUNK_CAPACITY);
        if (chunkIndex < 0) {
            archetype.chunks.push(createSchemaChunk(archetype.types));
            chunkIndex = archetype.chunks.length - 1;
            this.structuralVersion++;
        }
        const chunk = archetype.chunks[chunkIndex], row = chunk.count++;
        chunk.entities[row] = birth.entity;
        for(let typeIndex = 0; typeIndex < archetype.types.length; typeIndex++){
            const type = archetype.types[typeIndex], value = birth.values.find((entry)=>entry.component === type).value;
            for (const [fieldName, descriptor] of fieldsOf(type))writeColumn(chunk.columns[typeIndex][fieldName], descriptor.kind, row, Reflect.get(value, fieldName));
        }
        const slot = this.slot(birth.entity);
        slot.archetype = archetype;
        slot.chunk = chunkIndex;
        slot.row = row;
        slot.pending = false;
    }
    commitDeath(entity) {
        const slot = this.slot(entity);
        if (!slot?.archetype) return;
        const chunk = slot.archetype.chunks[slot.chunk], last = chunk.count - 1;
        if (slot.row !== last) {
            const moved = chunk.entities[last];
            chunk.entities[slot.row] = moved;
            this.slots[moved.index].row = slot.row;
            for (const column of chunk.columnList)copyColumnRow(column, last, slot.row);
        }
        chunk.entities[last] = undefined;
        for (const column of chunk.columnList)clearColumnRow(column, last);
        chunk.count--;
        slot.archetype = undefined;
        slot.chunk = -1;
        slot.row = -1;
        slot.pending = false;
        slot.generation++;
        this.free.push(entity.index);
    }
    enumerate() {
        return {
            archetypes: this.archetypes.map((archetype)=>({
                    components: archetype.types.map((type)=>type.name),
                    entities: archetype.chunks.flatMap((chunk)=>chunk.entities.slice(0, chunk.count).map((entity)=>entity.index)),
                    fields: archetype.types.map((type)=>({
                            component: type.name,
                            fields: Object.entries(type.fields).map(([name, descriptor])=>({
                                    name,
                                    kind: descriptor.kind,
                                    default: inspectFieldValue(descriptor.default)
                                }))
                        })),
                    chunks: archetype.chunks.map((chunk)=>({
                            capacity: CHUNK_CAPACITY,
                            count: chunk.count,
                            entities: chunk.entities.slice(0, chunk.count).map((entity)=>entity.index)
                        }))
                })),
            slots: this.slots.map((slot)=>({
                    generation: slot.generation,
                    row: slot.row,
                    pending: slot.pending,
                    ...slot.archetype ? {
                        chunk: slot.chunk
                    } : {}
                })),
            free: [
                ...this.free
            ],
            entities: enumerateEntities(this.archetypes)
        };
    }
    dispose() {
        if (this.disposed) return;
        this.disposed = true;
        this.epoch++;
        this.structuralVersion++;
        this.births.length = 0;
        this.deaths.clear();
        for (const archetype of this.archetypes)for (const chunk of archetype.chunks){
            chunk.count = 0;
            chunk.entities.fill(undefined);
            for (const columns of chunk.columns)for (const column of Object.values(columns))clearColumn(column);
        }
        this.archetypes.length = 0;
        this.slots.length = 0;
        this.free.length = 0;
    }
}
function createSchemaChunk(types) {
    const columns = types.map((type)=>Object.fromEntries(Object.entries(type.fields).map(([name, descriptor])=>[
                name,
                createColumn(descriptor.kind)
            ])));
    return {
        count: 0,
        entities: new Array(CHUNK_CAPACITY),
        columns,
        // Columns are never replaced; retain their existing component/field order.
        columnList: columns.flatMap((componentColumns)=>Object.values(componentColumns))
    };
}
function createColumn(kind) {
    switch(kind){
        case "f32":
            return new Float32Array(CHUNK_CAPACITY);
        case "f64":
            return new Float64Array(CHUNK_CAPACITY);
        case "i32":
            return new Int32Array(CHUNK_CAPACITY);
        case "u32":
            return new Uint32Array(CHUNK_CAPACITY);
        case "u8":
        case "bool":
            return new Uint8Array(CHUNK_CAPACITY);
        case "entity":
            return {
                index: new Uint32Array(CHUNK_CAPACITY),
                generation: new Uint32Array(CHUNK_CAPACITY)
            };
    }
}
function writeColumn(column, kind, row, value) {
    if (kind === "entity") {
        const reference = column;
        if (value === null) {
            reference.index[row] = 0;
            reference.generation[row] = 0;
        } else {
            const entity = value;
            reference.index[row] = entity.index + 1;
            reference.generation[row] = entity.generation;
        }
    } else column[row] = kind === "bool" ? value ? 1 : 0 : value;
}
function copyColumnRow(column, source, target) {
    if ("index" in column) {
        column.index[target] = column.index[source];
        column.generation[target] = column.generation[source];
    } else column[target] = column[source];
}
function clearColumnRow(column, row) {
    if ("index" in column) {
        column.index[row] = 0;
        column.generation[row] = 0;
    } else column[row] = 0;
}
function clearColumn(column) {
    if ("index" in column) {
        column.index.fill(0);
        column.generation.fill(0);
    } else column.fill(0);
}
function createChunkDescriptor(world, epoch, archetype, chunk, types) {
    const assertValid = ()=>{
        if (world.commitEpoch !== epoch) throw new Error("Schema chunk borrow has expired");
    };
    const componentViews = new Map();
    for (const type of types){
        const typeIndex = archetype.types.indexOf(type), view = {};
        for (const [fieldName, descriptor] of fieldsOf(type)){
            const column = chunk.columns[typeIndex][fieldName];
            const exposed = descriptor.kind === "entity" ? defineOpaque({}, {
                index: column.index,
                generation: column.generation
            }) : column;
            Object.defineProperty(view, fieldName, {
                value: exposed
            });
        }
        componentViews.set(type, Object.freeze(view));
    }
    const views = {};
    for (const type of types)Object.defineProperty(views, type.name, {
        get () {
            assertValid();
            return componentViews.get(type);
        }
    });
    Object.freeze(views);
    const descriptor = {};
    Object.defineProperties(descriptor, {
        count: {
            get () {
                assertValid();
                return chunk.count;
            }
        },
        capacity: {
            get () {
                assertValid();
                return CHUNK_CAPACITY;
            }
        },
        views: {
            get () {
                assertValid();
                return views;
            }
        },
        entityAt: {
            value (row) {
                assertValid();
                if (!Number.isInteger(row) || row < 0 || row >= chunk.count) throw new Error("Schema chunk row is outside the live range");
                return chunk.entities[row];
            }
        }
    });
    return Object.freeze(descriptor);
}
function defineOpaque(target, values) {
    for (const [name, value] of Object.entries(values))Object.defineProperty(target, name, {
        value
    });
    return Object.freeze(target);
}
function inspectColumnValue(column, descriptor, row) {
    if (descriptor.kind === "entity") {
        const reference = column;
        return reference.index[row] === 0 ? null : {
            index: reference.index[row] - 1,
            generation: reference.generation[row]
        };
    }
    const value = column[row];
    return descriptor.kind === "bool" ? value !== 0 : value;
}
function inspectFieldValue(value) {
    return isEntity(value) ? {
        index: value.index,
        generation: value.generation
    } : value;
}
function enumerateEntities(archetypes) {
    const entities = [];
    for (const archetype of archetypes){
        for (const chunk of archetype.chunks){
            for(let row = 0; row < chunk.count; row++){
                const entity = chunk.entities[row];
                entities.push({
                    index: entity.index,
                    generation: entity.generation,
                    components: archetype.types.map((type, typeIndex)=>({
                            name: type.name,
                            fields: Object.entries(type.fields).map(([fieldName, descriptor])=>({
                                    name: fieldName,
                                    kind: descriptor.kind,
                                    value: inspectColumnValue(chunk.columns[typeIndex][fieldName], descriptor, row)
                                }))
                        }))
                });
            }
        }
    }
    return entities;
}
function isSchemaComponent(value) {
    return typeof value === "object" && value !== null && SCHEMA_COMPONENT in value;
}
function isFieldDescriptor(value) {
    return typeof value === "object" && value !== null && "kind" in value && typeof value.kind === "string" && [
        "f32",
        "f64",
        "i32",
        "u32",
        "u8",
        "bool",
        "entity"
    ].includes(value.kind);
}
function isEntity(value) {
    return typeof value === "object" && value !== null && "index" in value && typeof value.index === "number" && Number.isInteger(value.index) && value.index >= 0 && "generation" in value && typeof value.generation === "number" && Number.isInteger(value.generation) && value.generation >= 0 && "owner" in value && typeof value.owner === "symbol";
}
function validateNumber(label, value) {
    if (typeof value !== "number" || !Number.isFinite(value)) throw new Error(`Invalid finite number: ${label}`);
    return value;
}
function validateF32(label, value) {
    const rounded = Math.fround(validateNumber(label, value));
    if (!Number.isFinite(rounded)) throw new Error(`Invalid finite float32: ${label}`);
    return rounded;
}
function validateInteger(label, value, min, max) {
    if (!Number.isInteger(value) || value < min || value > max) throw new Error(`Invalid integer: ${label}`);
    return value;
}
function validateDescriptorDefault(label, descriptor) {
    switch(descriptor.kind){
        case "f32":
            return validateF32(label, descriptor.default);
        case "f64":
            return validateNumber(label, descriptor.default);
        case "i32":
            return validateInteger(label, descriptor.default, -0x80000000, 0x7fffffff);
        case "u32":
            return validateInteger(label, descriptor.default, 0, 0xffffffff);
        case "u8":
            return validateInteger(label, descriptor.default, 0, 0xff);
        case "bool":
            if (typeof descriptor.default !== "boolean") throw new Error(`Invalid boolean: ${label}`);
            return descriptor.default;
        case "entity":
            if (descriptor.default !== null) throw new Error(`Entity reference defaults are always null: ${label}`);
            return null;
    }
}


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvamZhYmkvRG9jdW1lbnRzL1Byb2plY3RzL3Rlc3RzL25nbmUvc3JjL2Vjcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLGlCQUFpQjtBQUN2QixNQUFNLGNBQWMsT0FBTztBQUMzQixNQUFNLG1CQUFtQixPQUFPO0FBZ0JoQyxTQUFTLE1BQ0wsSUFBVSxFQUNWLFlBQW1CO0lBRW5CLE9BQU8sT0FBTyxNQUFNLENBQUM7UUFBRTtRQUFNLFNBQVM7UUFBYyxDQUFDLFlBQVksRUFBRTtJQUFhO0FBQ3BGO0FBRUEsT0FBTyxNQUFNLE1BQU0sQ0FBQyxlQUFlLENBQUMsR0FDaEMsTUFBTSxPQUFPLFlBQVksT0FBTyxlQUFlO0FBQ25ELE9BQU8sTUFBTSxNQUFNLENBQUMsZUFBZSxDQUFDLEdBQ2hDLE1BQU0sT0FBTyxlQUFlLE9BQU8sZUFBZTtBQUN0RCxPQUFPLE1BQU0sTUFBTSxDQUFDLGVBQWUsQ0FBQyxHQUNoQyxNQUFNLE9BQU8sZ0JBQWdCLE9BQU8sY0FBYyxDQUFDLFlBQVksYUFBYTtBQUNoRixPQUFPLE1BQU0sTUFBTSxDQUFDLGVBQWUsQ0FBQyxHQUNoQyxNQUFNLE9BQU8sZ0JBQWdCLE9BQU8sY0FBYyxHQUFHLGFBQWE7QUFDdEUsT0FBTyxNQUFNLEtBQUssQ0FBQyxlQUFlLENBQUMsR0FDL0IsTUFBTSxNQUFNLGdCQUFnQixNQUFNLGNBQWMsR0FBRyxPQUFPO0FBQzlELE9BQU8sTUFBTSxPQUFPLENBQUMsZUFBZSxLQUFLO0lBQ3JDLElBQUksT0FBTyxpQkFBaUIsV0FBVyxNQUFNLElBQUksTUFBTTtJQUN2RCxPQUFPLE1BQU0sUUFBUTtBQUN6QixFQUFFO0FBRUYsT0FBTyxTQUFTLFVBQVUsR0FBRyxhQUF3QjtJQUNqRCxJQUFJLGNBQWMsTUFBTSxHQUFHLEdBQUcsTUFBTSxJQUFJLE1BQU07SUFDOUMsT0FBTyxNQUFNLFVBQVU7QUFDM0I7QUFFQSxPQUFPLE1BQU07O0lBQ0EsQ0FBQyxpQkFBaUIsR0FBRyxLQUFLO0lBQzFCLE9BQWU7SUFDeEIsWUFDSSxBQUFTLElBQVUsRUFDbkIsTUFBYyxDQUNoQjthQUZXLE9BQUE7UUFHVCxJQUFJLENBQUMsTUFBTSxNQUFNLElBQUksTUFBTTtRQUMzQixJQUFJLE9BQU8sV0FBVyxZQUFZLFdBQVcsTUFDekMsTUFBTSxJQUFJLE1BQU0sQ0FBQywwQ0FBMEMsRUFBRSxNQUFNO1FBQ3ZFLE1BQU0sU0FBbUQsT0FBTyxNQUFNLENBQUM7UUFDdkUsS0FBSyxNQUFNLENBQUMsV0FBVyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsUUFBUztZQUMxRCxJQUFJLENBQUMsV0FBVyxNQUFNLElBQUksTUFBTTtZQUNoQyxJQUFJLENBQUMsa0JBQWtCLGFBQ25CLE1BQU0sSUFBSSxNQUFNLENBQUMsMEJBQTBCLEVBQUUsS0FBSyxDQUFDLEVBQUUsV0FBVztZQUNwRSxNQUFNLGVBQWUsMEJBQTBCLEdBQUcsS0FBSyxDQUFDLEVBQUUsV0FBVyxFQUFFO1lBQ3ZFLE1BQU0sQ0FBQyxVQUFVLEdBQUcsT0FBTyxNQUFNLENBQUM7Z0JBQzlCLE1BQU0sV0FBVyxJQUFJO2dCQUNyQixTQUFTO2dCQUNULENBQUMsWUFBWSxFQUFFO1lBQ25CO1FBQ0o7UUFDQSxJQUFJLENBQUMsTUFBTSxHQUFHLE9BQU8sTUFBTSxDQUFDO1FBQzVCLE9BQU8sTUFBTSxDQUFDLElBQUk7SUFDdEI7SUFDQSxHQUFHLFFBQXVDLENBQUMsQ0FBQyxFQUFzQztRQUM5RSxLQUFLLE1BQU0sYUFBYSxPQUFPLElBQUksQ0FBQyxPQUNoQyxJQUFJLENBQUMsQ0FBQyxhQUFhLElBQUksQ0FBQyxNQUFNLEdBQzFCLE1BQU0sSUFBSSxNQUFNLENBQUMseUJBQXlCLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsV0FBVztRQUM1RSxPQUFPO1lBQUUsV0FBVyxJQUFJO1lBQUU7UUFBTTtJQUNwQztBQUNKO0FBT0EsT0FBTyxTQUFTLFVBQ1osSUFBVSxFQUNWLE1BQWM7SUFFZCxPQUFPLElBQUksZ0JBQWdCLE1BQU07QUFDckM7QUFLQSxrRkFBa0Y7QUFDbEYsaUZBQWlGO0FBQ2pGLE1BQU0scUJBQXFCLElBQUk7QUFJL0IsU0FBUyxTQUFTLElBQXdCO0lBQ3RDLElBQUksU0FBUyxtQkFBbUIsR0FBRyxDQUFDO0lBQ3BDLElBQUksQ0FBQyxRQUFRO1FBQ1QsU0FBUyxPQUFPLE9BQU8sQ0FBQyxLQUFLLE1BQU07UUFDbkMsbUJBQW1CLEdBQUcsQ0FBQyxNQUFNO0lBQ2pDO0lBQ0EsT0FBTztBQUNYO0FBNEZBLE1BQU07SUFDTyxDQUFBLEtBQU0sQ0FBUTtJQUN2QixZQUFZLEtBQVksQ0FBRTtRQUN0QixJQUFJLENBQUMsQ0FBQSxLQUFNLEdBQUc7UUFDZCxPQUFPLE1BQU0sQ0FBQyxJQUFJO0lBQ3RCO0lBQ0EsSUFBSSxPQUFlO1FBQ2YsT0FBTyxJQUFJLENBQUMsQ0FBQSxLQUFNLENBQUMsSUFBSTtJQUMzQjtJQUNBLEtBQUssS0FBK0IsRUFBUTtRQUN4QyxJQUFJLENBQUMsQ0FBQSxLQUFNLENBQUMsU0FBUztRQUNyQixJQUFJO1lBQ0EsS0FBSyxNQUFNLGFBQWEsSUFBSSxDQUFDLENBQUEsS0FBTSxDQUFDLGFBQWEsQ0FDN0MsS0FBSyxNQUFNLFNBQVMsVUFBVSxNQUFNLENBQ2hDLElBQUssSUFBSSxNQUFNLEdBQUcsTUFBTSxNQUFNLEtBQUssRUFBRSxNQUFPLE1BQU0sTUFBTSxRQUFRLENBQUMsSUFBSTtRQUNqRixTQUFVO1lBQ04sSUFBSSxDQUFDLENBQUEsS0FBTSxDQUFDLE9BQU87UUFDdkI7SUFDSjtBQUNKO0FBRUEsTUFBTTtJQUdGLENBQUEsT0FBUSxHQUFHLENBQUMsRUFBRTtJQUNkLENBQUEsT0FBUSxHQUFnQixFQUFFLENBQUM7SUFDM0IsQ0FBQSxXQUFZLEdBQUcsQ0FBQyxFQUFFO0lBQ2xCLENBQUEsV0FBWSxHQUF5QixFQUFFLENBQUM7SUFDL0IsQ0FBQSxLQUFNLENBQVE7SUFDZCxDQUFBLEtBQU0sQ0FBUTtJQUN2QixZQUFZLEtBQVksRUFBRSxLQUFZLENBQUU7UUFDcEMsSUFBSSxDQUFDLENBQUEsS0FBTSxHQUFHO1FBQ2QsSUFBSSxDQUFDLENBQUEsS0FBTSxHQUFHO1FBQ2QsT0FBTyxNQUFNLENBQUMsSUFBSTtJQUN0QjtJQUNBLElBQUksT0FBZTtRQUNmLElBQUksQ0FBQyxPQUFPO1FBQ1osT0FBTyxJQUFJLENBQUMsQ0FBQSxPQUFRLENBQUMsTUFBTSxDQUN2QixDQUFDLE1BQU0sWUFDSCxPQUFPLFVBQVUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sUUFBVSxPQUFPLE1BQU0sS0FBSyxFQUFFLElBQ3hFO0lBRVI7SUFDQSxVQUFVLEtBQTBDLEVBQVE7UUFDeEQsSUFBSSxDQUFDLE9BQU87UUFDWixJQUFJLENBQUMsa0JBQWtCO1FBQ3ZCLElBQUksQ0FBQyxDQUFBLEtBQU0sQ0FBQyxTQUFTO1FBQ3JCLElBQUk7WUFDQSxLQUFLLE1BQU0sY0FBYyxJQUFJLENBQUMsQ0FBQSxXQUFZLENBQUUsSUFBSSxXQUFXLEtBQUssR0FBRyxHQUFHLE1BQU07UUFDaEYsU0FBVTtZQUNOLElBQUksQ0FBQyxDQUFBLEtBQU0sQ0FBQyxPQUFPO1FBQ3ZCO0lBQ0o7SUFDUSxVQUFnQjtRQUNwQixJQUFJLElBQUksQ0FBQyxDQUFBLE9BQVEsS0FBSyxJQUFJLENBQUMsQ0FBQSxLQUFNLENBQUMsZ0JBQWdCLEVBQUU7UUFDcEQsSUFBSSxDQUFDLENBQUEsT0FBUSxHQUFHLElBQUksQ0FBQyxDQUFBLEtBQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsWUFDOUMsSUFBSSxDQUFDLENBQUEsS0FBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQVMsVUFBVSxLQUFLLENBQUMsUUFBUSxDQUFDO1FBRXpELElBQUksQ0FBQyxDQUFBLE9BQVEsR0FBRyxJQUFJLENBQUMsQ0FBQSxLQUFNLENBQUMsZ0JBQWdCO1FBQzVDLElBQUksQ0FBQyxDQUFBLFdBQVksR0FBRyxDQUFDO0lBQ3pCO0lBQ1EscUJBQTJCO1FBQy9CLElBQUksSUFBSSxDQUFDLENBQUEsV0FBWSxLQUFLLElBQUksQ0FBQyxDQUFBLEtBQU0sQ0FBQyxXQUFXLEVBQUU7UUFDbkQsTUFBTSxRQUFRLElBQUksQ0FBQyxDQUFBLEtBQU0sQ0FBQyxXQUFXO1FBQ3JDLElBQUksQ0FBQyxDQUFBLFdBQVksR0FBRyxJQUFJLENBQUMsQ0FBQSxPQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsWUFDdkMsVUFBVSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsUUFDbEIsc0JBQXNCLElBQUksQ0FBQyxDQUFBLEtBQU0sRUFBRSxPQUFPLFdBQVcsT0FBTyxJQUFJLENBQUMsQ0FBQSxLQUFNO1FBRy9FLElBQUksQ0FBQyxDQUFBLFdBQVksR0FBRztJQUN4QjtBQUNKO0FBRUEsT0FBTyxNQUFNLENBQUMsZ0JBQWdCLFNBQVM7QUFDdkMsT0FBTyxNQUFNLENBQUMsbUJBQW1CLFNBQVM7QUFFMUMsTUFBTTtJQUNPLENBQUEsS0FBTSxDQUFRO0lBQ3ZCLFlBQVksS0FBWSxDQUFFO1FBQ3RCLElBQUksQ0FBQyxDQUFBLEtBQU0sR0FBRztRQUNkLGFBQWEsSUFBSSxFQUFFO1lBQ2YsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJO1lBQzNCLFNBQVMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSTtZQUMvQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUk7WUFDdkIsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJO1lBQ3pCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSTtZQUMzQixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUk7UUFDL0I7SUFDSjtJQUVBLE1BQU0sR0FBRyxNQUF3QixFQUFVO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLENBQUEsS0FBTSxDQUFDLFdBQVcsQ0FBQztJQUNuQztJQUNBLFFBQVEsTUFBYyxFQUFRO1FBQzFCLElBQUksQ0FBQyxDQUFBLEtBQU0sQ0FBQyxPQUFPLENBQUM7SUFDeEI7SUFDQSxJQUFJLE1BQWMsRUFBVztRQUN6QixPQUFPLElBQUksQ0FBQyxDQUFBLEtBQU0sQ0FBQyxHQUFHLENBQUM7SUFDM0I7SUFDQSxLQUNJLE1BQWMsRUFDZCxJQUFtQyxFQUNuQyxLQUFZLEVBQ3lCO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLENBQUEsS0FBTSxDQUFDLElBQUksQ0FBQyxRQUFRLE1BQU07SUFDMUM7SUFDQSxNQUNJLE1BQWMsRUFDZCxJQUFtQyxFQUNuQyxLQUFZLEVBQ1osS0FBZ0MsRUFDNUI7UUFDSixJQUFJLENBQUMsQ0FBQSxLQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsTUFBTSxPQUFPO0lBQzNDO0lBR0EsTUFBTSxHQUFHLEtBQTJCLEVBQWdEO1FBQ2hGLE9BQU8sSUFBSSxDQUFDLENBQUEsS0FBTSxDQUFDLFVBQVUsQ0FBQztJQUNsQztBQUNKO0FBRUEsT0FBTyxNQUFNLENBQUMsbUJBQW1CLFNBQVM7QUFFMUMsT0FBTyxNQUFNO0lBQ1EsUUFBUSxPQUFPLFNBQVM7SUFDeEIsUUFBZ0IsRUFBRSxDQUFDO0lBQ25CLE9BQWlCLEVBQUUsQ0FBQztJQUNwQixhQUEwQixFQUFFLENBQUM7SUFDN0IsU0FBeUIsRUFBRSxDQUFDO0lBQzVCLFNBQVMsSUFBSSxNQUFjO0lBQzNCLGNBQWMsSUFBSSxNQUFrQztJQUM3RCxVQUFVLEVBQUU7SUFDWixXQUFXLE1BQU07SUFDakIsb0JBQW9CLEVBQUU7SUFDdEIsUUFBUSxFQUFFO0lBQ1QsT0FBb0I7SUFDN0IsYUFBYztRQUNWLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxtQkFBbUIsSUFBSTtJQUM3QztJQUNBLElBQUksZ0JBQXNDO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLFVBQVU7SUFDMUI7SUFDQSxJQUFJLG1CQUEyQjtRQUMzQixPQUFPLElBQUksQ0FBQyxpQkFBaUI7SUFDakM7SUFDQSxJQUFJLGNBQXNCO1FBQ3RCLE9BQU8sSUFBSSxDQUFDLEtBQUs7SUFDckI7SUFDQSxJQUFJLE9BQWU7UUFDZixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUN6QixDQUFDLE1BQU0sWUFDSCxPQUFPLFVBQVUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sUUFBVSxPQUFPLE1BQU0sS0FBSyxFQUFFLElBQ3hFO0lBRVI7SUFDQSxJQUFJLFdBQW1CO1FBQ25CLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNO0lBQzVCO0lBQ0EsWUFBa0I7UUFDZCxJQUFJLENBQUMsT0FBTztJQUNoQjtJQUNBLFVBQWdCO1FBQ1osSUFBSSxDQUFDLE9BQU87SUFDaEI7SUFFQSxNQUFNLEdBQUcsTUFBd0IsRUFBVTtRQUN2QyxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUM7SUFDNUI7SUFDQSxZQUFZLE1BQXdCLEVBQVU7UUFDMUMsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFLE1BQU0sSUFBSSxNQUFNO1FBQ25DLEtBQUssTUFBTSxFQUFFLFdBQVcsSUFBSSxFQUFFLElBQUksT0FDOUIsSUFBSSxDQUFDLGtCQUFrQixPQUFPLE1BQU0sSUFBSSxNQUFNO1FBQ2xELElBQUksSUFBSSxJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsUUFBVSxNQUFNLFNBQVMsR0FBRyxJQUFJLEtBQUssT0FBTyxNQUFNLEVBQ3RFLE1BQU0sSUFBSSxNQUFNO1FBQ3BCLE1BQU0sVUFBVSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEVBQUUsV0FBVyxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUssQ0FBQztnQkFDeEQsV0FBVztnQkFDWCxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNO1lBQ3ZDLENBQUM7UUFDRCxLQUFLLE1BQU0sRUFBRSxXQUFXLElBQUksRUFBRSxJQUFJLE9BQVEsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1FBQ2xFLE1BQU0sUUFBUSxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU07UUFDbEQsTUFBTSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUFJO1lBQUUsWUFBWTtZQUFHLE9BQU8sQ0FBQztZQUFHLEtBQUssQ0FBQztZQUFHLFNBQVM7UUFBSztRQUNyRixLQUFLLE9BQU8sR0FBRztRQUNmLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHO1FBQ3BCLE1BQU0sU0FBUyxPQUFPLE1BQU0sQ0FBQztZQUFFO1lBQU8sWUFBWSxLQUFLLFVBQVU7WUFBRSxPQUFPLElBQUksQ0FBQyxLQUFLO1FBQUM7UUFDckYsS0FBSyxNQUFNLEdBQUc7UUFDZCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztZQUFFO1lBQVEsUUFBUTtRQUFRO1FBQzNDLE9BQU87SUFDWDtJQUNRLG1CQUFtQixJQUF3QixFQUFRO1FBQ3ZELE1BQU0sV0FBVyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLElBQUk7UUFDL0MsSUFBSSxZQUFZLGFBQWEsTUFDekIsTUFBTSxJQUFJLE1BQU0sQ0FBQyxnQ0FBZ0MsRUFBRSxLQUFLLElBQUksRUFBRTtRQUNsRSxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLElBQUksRUFBRTtJQUNwQztJQUNRLGlCQUFpQixJQUF3QixFQUFFLE9BQWUsRUFBVTtRQUN4RSxNQUFNLFFBQWlDLE9BQU8sTUFBTSxDQUFDO1FBQ3JELEtBQUssTUFBTSxhQUFhLE9BQU8sSUFBSSxDQUFDLFNBQ2hDLElBQUksQ0FBQyxDQUFDLGFBQWEsS0FBSyxNQUFNLEdBQzFCLE1BQU0sSUFBSSxNQUFNLENBQUMseUJBQXlCLEVBQUUsS0FBSyxJQUFJLENBQUMsQ0FBQyxFQUFFLFdBQVc7UUFDNUUsS0FBSyxNQUFNLENBQUMsV0FBVyxXQUFXLElBQUksU0FBUyxNQUFPO1lBQ2xELE1BQU0sWUFBWSxPQUFPLFNBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsYUFDMUQsUUFBUSxHQUFHLENBQUMsU0FBUyxhQUNyQjtZQUNOLE1BQU0sV0FBVyxjQUFjLFlBQVksV0FBVyxPQUFPLEdBQUc7WUFDaEUsS0FBSyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sV0FBVyxZQUFZO1FBQ3ZFO1FBQ0EsT0FBTztJQUNYO0lBQ1EsY0FDSixJQUF3QixFQUN4QixTQUFpQixFQUNqQixVQUFvQyxFQUNwQyxLQUFjLEVBQ1A7UUFDUCxNQUFNLFFBQVEsR0FBRyxLQUFLLElBQUksQ0FBQyxDQUFDLEVBQUUsV0FBVztRQUN6QyxPQUFRLFdBQVcsSUFBSTtZQUNuQixLQUFLO2dCQUNELE9BQU8sWUFBWSxPQUFPO1lBQzlCLEtBQUs7Z0JBQ0QsT0FBTyxlQUFlLE9BQU87WUFDakMsS0FBSztnQkFDRCxPQUFPLGdCQUFnQixPQUFPLE9BQU8sQ0FBQyxZQUFZO1lBQ3RELEtBQUs7Z0JBQ0QsT0FBTyxnQkFBZ0IsT0FBTyxPQUFPLEdBQUc7WUFDNUMsS0FBSztnQkFDRCxPQUFPLGdCQUFnQixPQUFPLE9BQU8sR0FBRztZQUM1QyxLQUFLO2dCQUNELElBQUksT0FBTyxVQUFVLFdBQVcsTUFBTSxJQUFJLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxPQUFPO2dCQUMzRSxPQUFPO1lBQ1gsS0FBSztnQkFDRCxJQUFJLFVBQVUsTUFBTSxPQUFPO2dCQUMzQixJQUFJLENBQUMsU0FBUyxRQUFRLE1BQU0sSUFBSSxNQUFNLENBQUMsMEJBQTBCLEVBQUUsT0FBTztnQkFDMUUsSUFBSSxNQUFNLEtBQUssS0FBSyxJQUFJLENBQUMsS0FBSyxFQUMxQixNQUFNLElBQUksTUFBTSxDQUFDLDBCQUEwQixFQUFFLE9BQU87Z0JBQ3hELE1BQU0sT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDO2dCQUNwQyxJQUNJLENBQUMsUUFDRCxNQUFNLFVBQVUsR0FBRyxLQUFLLFVBQVUsSUFDakMsTUFBTSxVQUFVLEtBQUssS0FBSyxVQUFVLElBQUksQ0FBQyxLQUFLLFNBQVMsSUFBSSxDQUFDLEtBQUssT0FBTyxFQUV6RSxNQUFNLElBQUksTUFBTSxDQUFDLDBCQUEwQixFQUFFLE9BQU87Z0JBQ3hELElBQUksTUFBTSxLQUFLLEdBQUcsSUFBSSxjQUFjLE1BQU0sVUFBVSxHQUFHLFlBQ25ELE1BQU0sSUFBSSxNQUFNLENBQUMseUNBQXlDLEVBQUUsT0FBTztnQkFDdkUsT0FBTztRQUNmO0lBQ0o7SUFDUSxLQUFLLE1BQWMsRUFBb0I7UUFDM0MsTUFBTSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxLQUFLLENBQUM7UUFDckMsT0FBTyxPQUFPLEtBQUssS0FBSyxJQUFJLENBQUMsS0FBSyxJQUFJLE1BQU0sZUFBZSxPQUFPLFVBQVUsR0FDdEUsT0FDQTtJQUNWO0lBQ0EsSUFBSSxNQUFjLEVBQVc7UUFDekIsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTO0lBQ2hDO0lBQ0EsS0FDSSxNQUFjLEVBQ2QsSUFBbUMsRUFDbkMsU0FBZ0IsRUFDcUI7UUFDckMsTUFBTSxhQUFhLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTTtRQUMzQyxNQUFNLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQztRQUN2QixJQUFJLENBQUMsTUFBTSxXQUFXLE9BQU87UUFDN0IsTUFBTSxZQUFZLEtBQUssU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDL0MsSUFBSSxZQUFZLEdBQUcsT0FBTztRQUMxQixNQUFNLFNBQVMsS0FBSyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxPQUFPLFdBQVc7UUFDdEYsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsWUFBWSxLQUFLLEdBQUc7SUFDdkQ7SUFDQSxNQUNJLE1BQWMsRUFDZCxJQUFtQyxFQUNuQyxTQUFnQixFQUNoQixLQUFnQyxFQUM1QjtRQUNKLE1BQU0sYUFBYSxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU07UUFDM0MsTUFBTSxZQUFZLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxPQUFPLFlBQVksWUFBWTtRQUMxRSxNQUFNLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQztRQUN2QixJQUFJLENBQUMsTUFBTSxXQUFXO1FBQ3RCLE1BQU0sWUFBWSxLQUFLLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1FBQy9DLElBQUksWUFBWSxHQUFHO1FBQ25CLFlBQ0ksS0FBSyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxPQUFPLFdBQVcsRUFDdkUsV0FBVyxJQUFJLEVBQ2YsS0FBSyxHQUFHLEVBQ1I7SUFFUjtJQUNRLGFBQ0osSUFBd0IsRUFDeEIsU0FBc0IsRUFDRTtRQUN4QixJQUFJLENBQUMsa0JBQWtCLE9BQU8sTUFBTSxJQUFJLE1BQU07UUFDOUMsTUFBTSxhQUFhLEtBQUssTUFBTSxDQUFDLE9BQU8sV0FBVztRQUNqRCxJQUFJLENBQUMsWUFDRCxNQUFNLElBQUksTUFBTSxDQUFDLHlCQUF5QixFQUFFLEtBQUssSUFBSSxDQUFDLENBQUMsRUFBRSxPQUFPLFlBQVk7UUFDaEYsT0FBTztJQUNYO0lBQ1EsV0FBVyxNQUFjLEVBQUUsVUFBb0MsRUFBRSxHQUFXLEVBQVc7UUFDM0YsSUFBSSxXQUFXLElBQUksS0FBSyxVQUFVO1lBQzlCLE1BQU0sWUFBWSxRQUNkLGVBQWUsVUFBVSxLQUFLLENBQUMsSUFBSTtZQUN2QyxJQUFJLGlCQUFpQixHQUFHLE9BQU87WUFDL0IsTUFBTSxRQUFRLGVBQWUsR0FDekIsYUFBYSxVQUFVLFVBQVUsQ0FBQyxJQUFJLEVBQ3RDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNO1lBQzVCLElBQUksTUFBTSxRQUFRLGVBQWUsWUFBWSxPQUFPLEtBQUssTUFBTTtZQUMvRCxPQUFPLE9BQU8sTUFBTSxDQUFDO2dCQUFFO2dCQUFPO2dCQUFZLE9BQU8sSUFBSSxDQUFDLEtBQUs7WUFBQztRQUNoRTtRQUNBLE1BQU0sVUFBVSxBQUFDLE1BQXdCLENBQUMsSUFBSTtRQUM5QyxPQUFPLFdBQVcsSUFBSSxLQUFLLFNBQVMsWUFBWSxJQUFJO0lBQ3hEO0lBQ0EsUUFBUSxNQUFjLEVBQVE7UUFDMUIsTUFBTSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDdkIsSUFBSSxRQUFRLENBQUMsS0FBSyxTQUFTLElBQUksS0FBSyxPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7SUFDbEU7SUFHQSxNQUFNLEdBQUcsS0FBMkIsRUFBZ0Q7UUFDaEYsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQzNCO0lBQ0EsV0FBVyxLQUEyQixFQUFnRDtRQUNsRixJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUUsTUFBTSxJQUFJLE1BQU07UUFDbkMsSUFBSSxNQUFNLE1BQU0sS0FBSyxHQUFHLE9BQU8sSUFBSSxnQkFBZ0IsSUFBSTtRQUN2RCxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsb0JBQW9CLE1BQU0sSUFBSSxNQUFNO1FBQ3JELElBQUksSUFBSSxJQUFJLE9BQU8sSUFBSSxLQUFLLE1BQU0sTUFBTSxFQUFFLE1BQU0sSUFBSSxNQUFNO1FBQzFELEtBQUssTUFBTSxRQUFRLE1BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDO1FBQ2xELE9BQU8sSUFBSSxtQkFBbUIsSUFBSSxFQUFFO0lBQ3hDO0lBQ0EsU0FBZTtRQUNYLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLElBQUksTUFBTTtRQUNsQyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUUsTUFBTSxJQUFJLE1BQU07UUFDbkMsSUFBSSxDQUFDLEtBQUs7UUFDVixLQUFLLE1BQU0sU0FBUyxJQUFJLENBQUMsTUFBTSxDQUFFLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDbEQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUc7UUFDckIsS0FBSyxNQUFNLFVBQVUsSUFBSSxDQUFDLE1BQU0sQ0FBRSxJQUFJLENBQUMsV0FBVyxDQUFDO1FBQ25ELElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSztJQUNyQjtJQUNRLFlBQVksS0FBbUIsRUFBUTtRQUMzQyxJQUFJLFlBQVksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQ2hDLENBQUMsWUFDRyxVQUFVLEtBQUssQ0FBQyxNQUFNLEtBQUssTUFBTSxNQUFNLENBQUMsTUFBTSxJQUM5QyxNQUFNLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFVLFVBQVUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLFNBQVM7UUFFOUUsSUFBSSxDQUFDLFdBQVc7WUFDWixZQUFZO2dCQUNSLE9BQU8sTUFBTSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBVSxNQUFNLFNBQVM7Z0JBQ2xELFFBQVEsRUFBRTtZQUNkO1lBQ0EsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7WUFDckIsSUFBSSxDQUFDLGlCQUFpQjtRQUMxQjtRQUNBLElBQUksYUFBYSxVQUFVLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFVLE1BQU0sS0FBSyxHQUFHO1FBQ3JFLElBQUksYUFBYSxHQUFHO1lBQ2hCLFVBQVUsTUFBTSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsVUFBVSxLQUFLO1lBQ3ZELGFBQWEsVUFBVSxNQUFNLENBQUMsTUFBTSxHQUFHO1lBQ3ZDLElBQUksQ0FBQyxpQkFBaUI7UUFDMUI7UUFDQSxNQUFNLFFBQVEsVUFBVSxNQUFNLENBQUMsV0FBVyxFQUN0QyxNQUFNLE1BQU0sS0FBSztRQUNyQixNQUFNLFFBQVEsQ0FBQyxJQUFJLEdBQUcsTUFBTSxNQUFNO1FBQ2xDLElBQUssSUFBSSxZQUFZLEdBQUcsWUFBWSxVQUFVLEtBQUssQ0FBQyxNQUFNLEVBQUUsWUFBYTtZQUNyRSxNQUFNLE9BQU8sVUFBVSxLQUFLLENBQUMsVUFBVSxFQUNuQyxRQUFRLE1BQU0sTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVUsTUFBTSxTQUFTLEtBQUssTUFBTyxLQUFLO1lBQ3pFLEtBQUssTUFBTSxDQUFDLFdBQVcsV0FBVyxJQUFJLFNBQVMsTUFDM0MsWUFDSSxNQUFNLE9BQU8sQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUNuQyxXQUFXLElBQUksRUFDZixLQUNBLFFBQVEsR0FBRyxDQUFDLE9BQU87UUFFL0I7UUFDQSxNQUFNLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLE1BQU07UUFDbkMsS0FBSyxTQUFTLEdBQUc7UUFDakIsS0FBSyxLQUFLLEdBQUc7UUFDYixLQUFLLEdBQUcsR0FBRztRQUNYLEtBQUssT0FBTyxHQUFHO0lBQ25CO0lBQ1EsWUFBWSxNQUFjLEVBQVE7UUFDdEMsTUFBTSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDdkIsSUFBSSxDQUFDLE1BQU0sV0FBVztRQUN0QixNQUFNLFFBQVEsS0FBSyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxDQUFDLEVBQzNDLE9BQU8sTUFBTSxLQUFLLEdBQUc7UUFDekIsSUFBSSxLQUFLLEdBQUcsS0FBSyxNQUFNO1lBQ25CLE1BQU0sUUFBUSxNQUFNLFFBQVEsQ0FBQyxLQUFLO1lBQ2xDLE1BQU0sUUFBUSxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUc7WUFDM0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDLEdBQUcsR0FBRyxLQUFLLEdBQUc7WUFDdEMsS0FBSyxNQUFNLFVBQVUsTUFBTSxVQUFVLENBQUUsY0FBYyxRQUFRLE1BQU0sS0FBSyxHQUFHO1FBQy9FO1FBQ0EsTUFBTSxRQUFRLENBQUMsS0FBSyxHQUFHO1FBQ3ZCLEtBQUssTUFBTSxVQUFVLE1BQU0sVUFBVSxDQUFFLGVBQWUsUUFBUTtRQUM5RCxNQUFNLEtBQUs7UUFDWCxLQUFLLFNBQVMsR0FBRztRQUNqQixLQUFLLEtBQUssR0FBRyxDQUFDO1FBQ2QsS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUNaLEtBQUssT0FBTyxHQUFHO1FBQ2YsS0FBSyxVQUFVO1FBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxLQUFLO0lBQy9CO0lBQ0EsWUFBb0I7UUFDaEIsT0FBTztZQUNILFlBQVksSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxZQUFjLENBQUM7b0JBQzVDLFlBQVksVUFBVSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBUyxLQUFLLElBQUk7b0JBQ25ELFVBQVUsVUFBVSxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsUUFDaEMsTUFBTSxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsTUFBTSxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUMsU0FBVyxPQUFRLEtBQUs7b0JBRXRFLFFBQVEsVUFBVSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBUyxDQUFDOzRCQUNuQyxXQUFXLEtBQUssSUFBSTs0QkFDcEIsUUFBUSxPQUFPLE9BQU8sQ0FBQyxLQUFLLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sV0FBVyxHQUFLLENBQUM7b0NBQzdEO29DQUNBLE1BQU0sV0FBVyxJQUFJO29DQUNyQixTQUFTLGtCQUFrQixXQUFXLE9BQU87Z0NBQ2pELENBQUM7d0JBQ0wsQ0FBQztvQkFDRCxRQUFRLFVBQVUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVUsQ0FBQzs0QkFDckMsVUFBVTs0QkFDVixPQUFPLE1BQU0sS0FBSzs0QkFDbEIsVUFBVSxNQUFNLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxNQUFNLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQyxTQUFXLE9BQVEsS0FBSzt3QkFDaEYsQ0FBQztnQkFDTCxDQUFDO1lBQ0QsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQVMsQ0FBQztvQkFDN0IsWUFBWSxLQUFLLFVBQVU7b0JBQzNCLEtBQUssS0FBSyxHQUFHO29CQUNiLFNBQVMsS0FBSyxPQUFPO29CQUNyQixHQUFJLEtBQUssU0FBUyxHQUFHO3dCQUFFLE9BQU8sS0FBSyxLQUFLO29CQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNuRCxDQUFDO1lBQ0QsTUFBTTttQkFBSSxJQUFJLENBQUMsSUFBSTthQUFDO1lBQ3BCLFVBQVUsa0JBQWtCLElBQUksQ0FBQyxVQUFVO1FBQy9DO0lBQ0o7SUFDQSxVQUFnQjtRQUNaLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtRQUNuQixJQUFJLENBQUMsUUFBUSxHQUFHO1FBQ2hCLElBQUksQ0FBQyxLQUFLO1FBQ1YsSUFBSSxDQUFDLGlCQUFpQjtRQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRztRQUNyQixJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7UUFDakIsS0FBSyxNQUFNLGFBQWEsSUFBSSxDQUFDLFVBQVUsQ0FDbkMsS0FBSyxNQUFNLFNBQVMsVUFBVSxNQUFNLENBQUU7WUFDbEMsTUFBTSxLQUFLLEdBQUc7WUFDZCxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUM7WUFDcEIsS0FBSyxNQUFNLFdBQVcsTUFBTSxPQUFPLENBQy9CLEtBQUssTUFBTSxVQUFVLE9BQU8sTUFBTSxDQUFDLFNBQVUsWUFBWTtRQUNqRTtRQUNKLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHO1FBQ3pCLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHO1FBQ3BCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHO0lBQ3ZCO0FBQ0o7QUFFQSxTQUFTLGtCQUFrQixLQUFvQztJQUMzRCxNQUFNLFVBQVUsTUFBTSxHQUFHLENBQUMsQ0FBQyxPQUN2QixPQUFPLFdBQVcsQ0FDZCxPQUFPLE9BQU8sQ0FBQyxLQUFLLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sV0FBVyxHQUFLO2dCQUNwRDtnQkFDQSxhQUFhLFdBQVcsSUFBSTthQUMvQjtJQUdULE9BQU87UUFDSCxPQUFPO1FBQ1AsVUFBVSxJQUFJLE1BQTBCO1FBQ3hDO1FBQ0EsMkVBQTJFO1FBQzNFLFlBQVksUUFBUSxPQUFPLENBQUMsQ0FBQyxtQkFBcUIsT0FBTyxNQUFNLENBQUM7SUFDcEU7QUFDSjtBQUNBLFNBQVMsYUFBYSxJQUFlO0lBQ2pDLE9BQVE7UUFDSixLQUFLO1lBQ0QsT0FBTyxJQUFJLGFBQWE7UUFDNUIsS0FBSztZQUNELE9BQU8sSUFBSSxhQUFhO1FBQzVCLEtBQUs7WUFDRCxPQUFPLElBQUksV0FBVztRQUMxQixLQUFLO1lBQ0QsT0FBTyxJQUFJLFlBQVk7UUFDM0IsS0FBSztRQUNMLEtBQUs7WUFDRCxPQUFPLElBQUksV0FBVztRQUMxQixLQUFLO1lBQ0QsT0FBTztnQkFDSCxPQUFPLElBQUksWUFBWTtnQkFDdkIsWUFBWSxJQUFJLFlBQVk7WUFDaEM7SUFDUjtBQUNKO0FBQ0EsU0FBUyxZQUFZLE1BQWMsRUFBRSxJQUFlLEVBQUUsR0FBVyxFQUFFLEtBQWM7SUFDN0UsSUFBSSxTQUFTLFVBQVU7UUFDbkIsTUFBTSxZQUFZO1FBQ2xCLElBQUksVUFBVSxNQUFNO1lBQ2hCLFVBQVUsS0FBSyxDQUFDLElBQUksR0FBRztZQUN2QixVQUFVLFVBQVUsQ0FBQyxJQUFJLEdBQUc7UUFDaEMsT0FBTztZQUNILE1BQU0sU0FBUztZQUNmLFVBQVUsS0FBSyxDQUFDLElBQUksR0FBRyxPQUFPLEtBQUssR0FBRztZQUN0QyxVQUFVLFVBQVUsQ0FBQyxJQUFJLEdBQUcsT0FBTyxVQUFVO1FBQ2pEO0lBQ0osT0FBTyxBQUFDLE1BQXdCLENBQUMsSUFBSSxHQUFHLFNBQVMsU0FBVSxRQUFRLElBQUksSUFBTTtBQUNqRjtBQUNBLFNBQVMsY0FBYyxNQUFjLEVBQUUsTUFBYyxFQUFFLE1BQWM7SUFDakUsSUFBSSxXQUFXLFFBQVE7UUFDbkIsT0FBTyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU8sS0FBSyxDQUFDLE9BQU87UUFDM0MsT0FBTyxVQUFVLENBQUMsT0FBTyxHQUFHLE9BQU8sVUFBVSxDQUFDLE9BQU87SUFDekQsT0FBTyxNQUFNLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPO0FBQzFDO0FBQ0EsU0FBUyxlQUFlLE1BQWMsRUFBRSxHQUFXO0lBQy9DLElBQUksV0FBVyxRQUFRO1FBQ25CLE9BQU8sS0FBSyxDQUFDLElBQUksR0FBRztRQUNwQixPQUFPLFVBQVUsQ0FBQyxJQUFJLEdBQUc7SUFDN0IsT0FBTyxNQUFNLENBQUMsSUFBSSxHQUFHO0FBQ3pCO0FBQ0EsU0FBUyxZQUFZLE1BQWM7SUFDL0IsSUFBSSxXQUFXLFFBQVE7UUFDbkIsT0FBTyxLQUFLLENBQUMsSUFBSSxDQUFDO1FBQ2xCLE9BQU8sVUFBVSxDQUFDLElBQUksQ0FBQztJQUMzQixPQUFPLE9BQU8sSUFBSSxDQUFDO0FBQ3ZCO0FBRUEsU0FBUyxzQkFDTCxLQUFZLEVBQ1osS0FBYSxFQUNiLFNBQW9CLEVBQ3BCLEtBQXlCLEVBQ3pCLEtBQVk7SUFFWixNQUFNLGNBQWM7UUFDaEIsSUFBSSxNQUFNLFdBQVcsS0FBSyxPQUFPLE1BQU0sSUFBSSxNQUFNO0lBQ3JEO0lBQ0EsTUFBTSxpQkFBaUIsSUFBSTtJQUMzQixLQUFLLE1BQU0sUUFBUSxNQUFPO1FBQ3RCLE1BQU0sWUFBWSxVQUFVLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FDdEMsT0FBTyxDQUFDO1FBQ1osS0FBSyxNQUFNLENBQUMsV0FBVyxXQUFXLElBQUksU0FBUyxNQUFPO1lBQ2xELE1BQU0sU0FBUyxNQUFNLE9BQU8sQ0FBQyxVQUFVLENBQUMsVUFBVTtZQUNsRCxNQUFNLFVBQ0YsV0FBVyxJQUFJLEtBQUssV0FDZCxhQUNJLENBQUMsR0FDRDtnQkFDSSxPQUFPLEFBQUMsT0FBaUMsS0FBSztnQkFDOUMsWUFBWSxBQUFDLE9BQWlDLFVBQVU7WUFDNUQsS0FFSjtZQUNWLE9BQU8sY0FBYyxDQUFDLE1BQU0sV0FBVztnQkFBRSxPQUFPO1lBQVE7UUFDNUQ7UUFDQSxlQUFlLEdBQUcsQ0FBQyxNQUFNLE9BQU8sTUFBTSxDQUFDO0lBQzNDO0lBQ0EsTUFBTSxRQUFRLENBQUM7SUFDZixLQUFLLE1BQU0sUUFBUSxNQUNmLE9BQU8sY0FBYyxDQUFDLE9BQU8sS0FBSyxJQUFJLEVBQUU7UUFDcEM7WUFDSTtZQUNBLE9BQU8sZUFBZSxHQUFHLENBQUM7UUFDOUI7SUFDSjtJQUNKLE9BQU8sTUFBTSxDQUFDO0lBQ2QsTUFBTSxhQUFhLENBQUM7SUFDcEIsT0FBTyxnQkFBZ0IsQ0FBQyxZQUFZO1FBQ2hDLE9BQU87WUFDSDtnQkFDSTtnQkFDQSxPQUFPLE1BQU0sS0FBSztZQUN0QjtRQUNKO1FBQ0EsVUFBVTtZQUNOO2dCQUNJO2dCQUNBLE9BQU87WUFDWDtRQUNKO1FBQ0EsT0FBTztZQUNIO2dCQUNJO2dCQUNBLE9BQU87WUFDWDtRQUNKO1FBQ0EsVUFBVTtZQUNOLE9BQU0sR0FBVztnQkFDYjtnQkFDQSxJQUFJLENBQUMsT0FBTyxTQUFTLENBQUMsUUFBUSxNQUFNLEtBQUssT0FBTyxNQUFNLEtBQUssRUFDdkQsTUFBTSxJQUFJLE1BQU07Z0JBQ3BCLE9BQU8sTUFBTSxRQUFRLENBQUMsSUFBSTtZQUM5QjtRQUNKO0lBQ0o7SUFDQSxPQUFPLE9BQU8sTUFBTSxDQUFDO0FBQ3pCO0FBQ0EsU0FBUyxhQUErQixNQUFTLEVBQUUsTUFBK0I7SUFDOUUsS0FBSyxNQUFNLENBQUMsTUFBTSxNQUFNLElBQUksT0FBTyxPQUFPLENBQUMsUUFDdkMsT0FBTyxjQUFjLENBQUMsUUFBUSxNQUFNO1FBQUU7SUFBTTtJQUNoRCxPQUFPLE9BQU8sTUFBTSxDQUFDO0FBQ3pCO0FBQ0EsU0FBUyxtQkFDTCxNQUFjLEVBQ2QsVUFBb0MsRUFDcEMsR0FBVztJQUVYLElBQUksV0FBVyxJQUFJLEtBQUssVUFBVTtRQUM5QixNQUFNLFlBQVk7UUFDbEIsT0FBTyxVQUFVLEtBQUssQ0FBQyxJQUFJLEtBQUssSUFDMUIsT0FDQTtZQUFFLE9BQU8sVUFBVSxLQUFLLENBQUMsSUFBSSxHQUFHO1lBQUcsWUFBWSxVQUFVLFVBQVUsQ0FBQyxJQUFJO1FBQUM7SUFDbkY7SUFDQSxNQUFNLFFBQVEsQUFBQyxNQUF3QixDQUFDLElBQUk7SUFDNUMsT0FBTyxXQUFXLElBQUksS0FBSyxTQUFTLFVBQVUsSUFBSTtBQUN0RDtBQUNBLFNBQVMsa0JBQWtCLEtBQWM7SUFDckMsT0FBTyxTQUFTLFNBQVM7UUFBRSxPQUFPLE1BQU0sS0FBSztRQUFFLFlBQVksTUFBTSxVQUFVO0lBQUMsSUFBSTtBQUNwRjtBQUNBLFNBQVMsa0JBQWtCLFVBQWdDO0lBQ3ZELE1BQU0sV0FBcUIsRUFBRTtJQUM3QixLQUFLLE1BQU0sYUFBYSxXQUFZO1FBQ2hDLEtBQUssTUFBTSxTQUFTLFVBQVUsTUFBTSxDQUFFO1lBQ2xDLElBQUssSUFBSSxNQUFNLEdBQUcsTUFBTSxNQUFNLEtBQUssRUFBRSxNQUFPO2dCQUN4QyxNQUFNLFNBQVMsTUFBTSxRQUFRLENBQUMsSUFBSTtnQkFDbEMsU0FBUyxJQUFJLENBQUM7b0JBQ1YsT0FBTyxPQUFPLEtBQUs7b0JBQ25CLFlBQVksT0FBTyxVQUFVO29CQUM3QixZQUFZLFVBQVUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sWUFBYyxDQUFDOzRCQUNsRCxNQUFNLEtBQUssSUFBSTs0QkFDZixRQUFRLE9BQU8sT0FBTyxDQUFDLEtBQUssTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVyxXQUFXLEdBQUssQ0FBQztvQ0FDbEUsTUFBTTtvQ0FDTixNQUFNLFdBQVcsSUFBSTtvQ0FDckIsT0FBTyxtQkFDSCxNQUFNLE9BQU8sQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUNuQyxZQUNBO2dDQUVSLENBQUM7d0JBQ0wsQ0FBQztnQkFDTDtZQUNKO1FBQ0o7SUFDSjtJQUNBLE9BQU87QUFDWDtBQUNBLFNBQVMsa0JBQWtCLEtBQWM7SUFDckMsT0FBTyxPQUFPLFVBQVUsWUFBWSxVQUFVLFFBQVEsb0JBQW9CO0FBQzlFO0FBQ0EsU0FBUyxrQkFBa0IsS0FBYztJQUNyQyxPQUNJLE9BQU8sVUFBVSxZQUNqQixVQUFVLFFBQ1YsVUFBVSxTQUNWLE9BQU8sTUFBTSxJQUFJLEtBQUssWUFDdEI7UUFBQztRQUFPO1FBQU87UUFBTztRQUFPO1FBQU07UUFBUTtLQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sSUFBSTtBQUVoRjtBQUNBLFNBQVMsU0FBUyxLQUFjO0lBQzVCLE9BQ0ksT0FBTyxVQUFVLFlBQ2pCLFVBQVUsUUFDVixXQUFXLFNBQ1gsT0FBTyxNQUFNLEtBQUssS0FBSyxZQUN2QixPQUFPLFNBQVMsQ0FBQyxNQUFNLEtBQUssS0FDNUIsTUFBTSxLQUFLLElBQUksS0FDZixnQkFBZ0IsU0FDaEIsT0FBTyxNQUFNLFVBQVUsS0FBSyxZQUM1QixPQUFPLFNBQVMsQ0FBQyxNQUFNLFVBQVUsS0FDakMsTUFBTSxVQUFVLElBQUksS0FDcEIsV0FBVyxTQUNYLE9BQU8sTUFBTSxLQUFLLEtBQUs7QUFFL0I7QUFDQSxTQUFTLGVBQWUsS0FBYSxFQUFFLEtBQWM7SUFDakQsSUFBSSxPQUFPLFVBQVUsWUFBWSxDQUFDLE9BQU8sUUFBUSxDQUFDLFFBQzlDLE1BQU0sSUFBSSxNQUFNLENBQUMsdUJBQXVCLEVBQUUsT0FBTztJQUNyRCxPQUFPO0FBQ1g7QUFDQSxTQUFTLFlBQVksS0FBYSxFQUFFLEtBQWM7SUFDOUMsTUFBTSxVQUFVLEtBQUssTUFBTSxDQUFDLGVBQWUsT0FBTztJQUNsRCxJQUFJLENBQUMsT0FBTyxRQUFRLENBQUMsVUFBVSxNQUFNLElBQUksTUFBTSxDQUFDLHdCQUF3QixFQUFFLE9BQU87SUFDakYsT0FBTztBQUNYO0FBQ0EsU0FBUyxnQkFBZ0IsS0FBYSxFQUFFLEtBQWMsRUFBRSxHQUFXLEVBQUUsR0FBVztJQUM1RSxJQUFJLENBQUMsT0FBTyxTQUFTLENBQUMsVUFBVSxBQUFDLFFBQW1CLE9BQU8sQUFBQyxRQUFtQixLQUMzRSxNQUFNLElBQUksTUFBTSxDQUFDLGlCQUFpQixFQUFFLE9BQU87SUFDL0MsT0FBTztBQUNYO0FBRUEsU0FBUywwQkFBMEIsS0FBYSxFQUFFLFVBQW9DO0lBQ2xGLE9BQVEsV0FBVyxJQUFJO1FBQ25CLEtBQUs7WUFDRCxPQUFPLFlBQVksT0FBTyxXQUFXLE9BQU87UUFDaEQsS0FBSztZQUNELE9BQU8sZUFBZSxPQUFPLFdBQVcsT0FBTztRQUNuRCxLQUFLO1lBQ0QsT0FBTyxnQkFBZ0IsT0FBTyxXQUFXLE9BQU8sRUFBRSxDQUFDLFlBQVk7UUFDbkUsS0FBSztZQUNELE9BQU8sZ0JBQWdCLE9BQU8sV0FBVyxPQUFPLEVBQUUsR0FBRztRQUN6RCxLQUFLO1lBQ0QsT0FBTyxnQkFBZ0IsT0FBTyxXQUFXLE9BQU8sRUFBRSxHQUFHO1FBQ3pELEtBQUs7WUFDRCxJQUFJLE9BQU8sV0FBVyxPQUFPLEtBQUssV0FDOUIsTUFBTSxJQUFJLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxPQUFPO1lBQy9DLE9BQU8sV0FBVyxPQUFPO1FBQzdCLEtBQUs7WUFDRCxJQUFJLFdBQVcsT0FBTyxLQUFLLE1BQ3ZCLE1BQU0sSUFBSSxNQUFNLENBQUMsMkNBQTJDLEVBQUUsT0FBTztZQUN6RSxPQUFPO0lBQ2Y7QUFDSiJ9