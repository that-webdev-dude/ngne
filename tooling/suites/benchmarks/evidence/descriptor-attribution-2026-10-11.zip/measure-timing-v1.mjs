import { World, component, f32, f64, u8 } from '../../src/ecs.ts';
import { Session } from 'node:inspector/promises';
import { PerformanceObserver } from 'node:perf_hooks';
import { writeHeapSnapshot } from 'node:v8';
import { writeFileSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { cpus, release } from 'node:os';
import assert from 'node:assert/strict';
const [mode, name, label] = process.argv.slice(2);
const dir = new URL('./', import.meta.url);
const save = (name, value) => writeFileSync(new URL(name, dir), JSON.stringify(value));
function fixture(name) {
  const world = new World();
  const queries = [], callbacks = [];
  let visits = 0, rows = 0;
  if (name === 'density') {
    const State = component('state', {x:f32(),y:f32(),vx:f32(1),vy:f32(2),age:f32(),weight:f32(1),kind:u8()});
    for(let i=0;i<128000;i++) world.spawn(State.of({x:i,y:i*2}));
    queries.push(world.query(State));
    callbacks.push(chunk => { const state=chunk.views.state; visits++; rows+=chunk.count; });
  } else {
    for(let system=0;system<12;system++) {
      const State=component(`small-state-${system}`,{x:f64(),y:f64(),dx:f64(1),dy:f64(2),age:f64(),energy:f64(100),weight:f64(1),speed:f64(1)});
      for(let row=0;row<16;row++) world.spawn(State.of());
      queries.push(world.query(State));
      callbacks.push(chunk => {const state=chunk.views[State.name]; visits++; rows+=chunk.count; for(let row=0;row<chunk.count;row++){ state.x[row]+=state.dx[row]*state.speed[row]; state.y[row]+=state.dy[row]*state.speed[row];state.age[row]++;state.energy[row]-=state.weight[row]*0.001; }});
    }
  }
  world.commit();
  function traverse() {visits=0;rows=0;for(let i=0;i<queries.length;i++)queries[i].eachChunk(callbacks[i]);if(name==='small')queries[0].eachChunk(callbacks[0]);}
  traverse();
  assert.equal(visits,name==='density'?250:13); assert.equal(rows,name==='density'?128000:208);
  const roots=[];for(const query of queries)query.eachChunk(chunk=>roots.push(chunk));
  const first=roots[0], views=first.views, view=views[Object.getOwnPropertyNames(views)[0]];
  assert.ok(view.x instanceof (name==='density'?Float32Array:Float64Array));
  for(const obj of [first,views,view]){assert.equal(Object.isFrozen(obj),true);assert.deepEqual(Object.keys(obj),[]);}
  let same;queries[0].eachChunk(chunk=>{same??=chunk;});assert.equal(same,first);
  world.commit();assert.throws(()=>first.count,/expired/);assert.throws(()=>views[Object.getOwnPropertyNames(views)[0]],/expired/);
  traverse();assert.throws(()=>first.count,/expired/);
  return {world,queries,traverse,descriptorCount:name==='density'?250:12, batch:name==='density'?1:16};
}
const names=name==='both'?['density','small']:[name];
const output={mode,name,label,pid:process.pid,node:process.version,argv:process.execArgv,platform:process.platform,os:release(),cpu:cpus()[0].model,ecsSha256:createHash('sha256').update(readFileSync(new URL('../../src/ecs.ts',import.meta.url))).digest('hex'),workloads:[]};
for(const workload of names){
 const f=fixture(workload);
 const samples=[];
 function tick(record=false){const a=performance.now();f.world.commit();const b=performance.now();f.traverse();const c=performance.now();f.traverse();const d=performance.now();if(record)samples.push([b-a,c-b,d-c]);}
 for(let i=0;i<100*f.batch;i++)tick();
 const gc=[];const obs=new PerformanceObserver(list=>{for(const e of list.getEntries())gc.push({start:e.startTime,duration:e.duration,detail:e.detail});});
 let profile, session;
 if(mode!=='timing'){global.gc();await new Promise(setImmediate);obs.observe({entryTypes:['gc']});session=new Session();session.connect();
 if(mode==='cpu'){await session.post('Profiler.enable');await session.post('Profiler.setSamplingInterval',{interval:100});await session.post('Profiler.start');}
 if(mode==='heap'){await session.post('HeapProfiler.startSampling',{samplingInterval:8192,includeObjectsCollectedByMajorGC:true,includeObjectsCollectedByMinorGC:true});}}
 const iterations=mode==='timing'?300*f.batch:mode==='cpu'?(workload==='density'?8000:96000):(workload==='density'?2000:24000);
 const start=performance.now();
 if(mode==='timing')for(let i=0;i<iterations;i++)tick(true);
 else for(let i=0;i<iterations;i++){f.world.commit();f.traverse();}
 const end=performance.now();
 if(mode==='cpu')profile=(await session.post('Profiler.stop')).profile;
 if(mode==='heap')profile=(await session.post('HeapProfiler.stopSampling')).profile;
 if(session){session.disconnect();await new Promise(setImmediate);await new Promise(setImmediate);obs.disconnect();save(`${label}-${workload}.${mode==='cpu'?'cpuprofile':'heapprofile'}`,profile);}
 const result={workload,iterations,descriptorCount:f.descriptorCount,expectedDescriptorBuilds:iterations*f.descriptorCount,batchesPerEstablishedSample:f.batch,columns:['commit','first','sameEpoch'],start,end,elapsed:end-start,samples,gc:gc.filter(e=>e.start>=start&&e.start<end),correctness:'row/chunk counts, typed arrays, freeze/opacity, same-epoch identity and stale epoch guards checked'};
 output.workloads.push(result);
 if(mode==='heap'&&workload==='small'){const roots=[];for(const q of f.queries)q.eachChunk(chunk=>roots.push(chunk));globalThis.descriptorAttributionRoots=roots;global.gc();result.heapSnapshot=writeHeapSnapshot(new URL(`${label}-small.heapsnapshot`,dir).pathname.replace(/^\/([A-Za-z]:)/,'$1'));delete globalThis.descriptorAttributionRoots;}
 f.world.dispose();
}
save(`${label}.json`,output);
console.log(JSON.stringify({label,pid:process.pid,workloads:output.workloads.map(({workload,iterations,elapsed,gc})=>({workload,iterations,elapsed,gcCount:gc.length}))}));
