# Frame sorting investigation

Evidence date: 2026-10-15. Branch: codex/gh37-frame-sort-investigation. Baseline: 4f94758ee110e32c394ea72d7450a400d27983c6 (@ngne/core 0.2.2). Engine, demo submissions and authoritative documentation are unchanged. Diagnostic work is uncommitted; full overlays, build inputs and hashes are retained.

Investigation and proposal only. No replacement algorithm has been implemented, prototyped or benchmarked.

## Measurement method

- Windows 10.0.26200 x64, Node 24.15.0, i7-12650H, Chrome 155.0.8059.79, hardware WebGPU Intel gen-12lp (Intel UHD, driver 31.0.101.4314). DPR 1.25; requested window 1500×1100, observed viewport 1487×788. Backing canvases: ordering 1440×900; Chaos 640×400. Browser is headed; selected sample windows were visible. No manual display/device acceptance is claimed.
- Vite 7.3.1 minified source builds with source maps; fresh profile and browser per case; no CPU/allocation profiler. Existing no-backgrounding flags enabled and recorded. Machine power/thermal state was not controlled.
- Three separate clean invocations and three separate boundary-timed invocations. Workloads reverse order between invocations; clean and diagnostic modes are interleaved. Each ordering case has 5 seconds warmup and 10 seconds sampling. Chaos is exactly 900 unchanged ticks: seed bench, scene key chaos, alpha 0.5; ticks 1–101 warmup and 102–900 measured (799). One Game.tick per RAF is a deterministic replay, not BrowserGame overload/drop-tick measurement.
- Clean means detail=0, no injected renderer timers and no sort wrapper. Diagnostic mode only inserts boundary timers into the existing prepare body; the comparison sort, validation, allocation and scalar gather statements remain intact. Sort includes active-prefix trimming. Validation includes liveness, stats reset, count and texture checks. Growth includes the capacity check; steady samples have no allocations.
- Audit mode is separate: read-only runtime key inspection, a full eligibility-only scan, key-distribution recording and observation of existing comparator output. Its scan timer excludes reflection/type checks, distributions and the canonical-output scan. Audit CPU/cadence results are excluded from clean or stage baselines.
- Each value below is one invocation's arithmetic mean or tail, in chronological invocation order within that mode. No frames are pooled across repetitions. CPU times exclude asynchronous GPU execution and presentation; encodeSubmit is CPU encoding/queue-call duration.

## Current CPU stage costs

Ranges span three per-invocation arithmetic means, ms/frame.

| Workload | Diagnostic sort | Diagnostic gather | Diagnostic validation | Clean prepare | Clean full CPU |
| --- | ---: | ---: | ---: | ---: | ---: |
| 64000 ordered | 0.862–1.559 | 0.899–1.748 | 0.255–0.378 | 2.625–4.035 | 6.108–9.062 |
| 64000 shuffled | 5.569–7.866 | 1.256–1.698 | 0.234–0.334 | 7.122–10.177 | 9.847–14.109 |
| 128000 ordered | 1.680–2.390 | 2.102–2.830 | 0.410–0.592 | 5.015–6.276 | 9.253–11.515 |
| 128000 shuffled | 9.481–16.194 | 2.200–3.691 | 0.400–0.638 | 14.386–21.428 | 17.821–26.807 |
| Chaos | 0.146–0.182 | 0.161–0.209 | 0.035–0.043 | 0.325–0.395 | 1.827–2.038 |

Full repetitions (ms/frame), retained independently:

| Workload | Clean CPU means | Diagnostic sort means | Diagnostic gather means | Diagnostic validation means | Diagnostic CPU means |
| --- | --- | --- | --- | --- | --- |
| 64000 ordered | 7.439 / 9.062 / 6.108 | 1.559 / 1.167 / 0.862 | 1.748 / 1.281 / 0.899 | 0.378 / 0.303 / 0.255 | 8.201 / 6.320 / 4.702 |
| 64000 shuffled | 14.109 / 13.821 / 9.847 | 7.866 / 6.795 / 5.569 | 1.698 / 1.468 / 1.256 | 0.334 / 0.286 / 0.234 | 13.672 / 11.925 / 9.795 |
| 128000 ordered | 11.515 / 11.100 / 9.253 | 2.390 / 2.347 / 1.680 | 2.830 / 2.651 / 2.102 | 0.592 / 0.552 / 0.410 | 10.623 / 10.288 / 7.659 |
| 128000 shuffled | 26.807 / 23.545 / 17.821 | 16.194 / 13.236 / 9.481 | 3.691 / 2.959 / 2.200 | 0.638 / 0.538 / 0.400 | 25.368 / 20.879 / 15.064 |
| Chaos | 2.038 / 1.827 / 1.890 | 0.182 / 0.146 / 0.154 | 0.209 / 0.161 / 0.161 | 0.043 / 0.037 / 0.035 | 2.245 / 1.829 / 1.744 |

Clean CPU and RAF-cadence tails (ms); these are not GPU times or dropped-tick counts:

| Workload | CPU p95 | CPU p99 | Cadence p95 | Cadence p99 |
| --- | --- | --- | --- | --- |
| 64000 ordered | 10.200 / 11.600 / 8.500 | 11.500 / 12.700 / 9.900 | 10.600 / 12.000 / 8.800 | 11.900 / 13.100 / 10.200 |
| 64000 shuffled | 18.800 / 18.900 / 11.900 | 20.600 / 22.100 / 14.100 | 19.300 / 19.200 / 12.200 | 21.000 / 22.700 / 14.400 |
| 128000 ordered | 14.900 / 15.400 / 11.900 | 16.500 / 17.600 / 13.500 | 15.300 / 15.800 / 12.100 | 17.000 / 18.200 / 13.800 |
| 128000 shuffled | 36.000 / 32.600 / 21.000 | 39.500 / 35.300 / 26.100 | 36.400 / 32.900 / 21.300 | 39.900 / 35.600 / 26.300 |
| Chaos | 2.700 / 2.400 / 4.200 | 3.500 / 2.700 / 6.100 | 7.100 / 7.100 / 7.200 | 7.800 / 7.200 / 7.400 |

Growth-event details (including cold frames) are in summary.json and every raw measurement. There are 0 growth events in accepted clean/diagnostic sample windows. The tiny steady growth-check timer is resolution-limited; it is not an allocation cost. Diagnostic-minus-clean differences are not a causal estimate of timer overhead; run spread and build/JIT differences remain.

## Applicability audit

| Workload | Audited sampled frames | Identity input | Canonical identity output | Eligible at hypothetical 4096/64 guard | Scan mean / p95, ms | Layer range |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| 64000 ordered | 207 | 207 | 207 | 207 | 0.193 / 0.300 | 0…3 |
| 64000 shuffled | 136 | 136 | 0 | 136 | 0.260 / 0.500 | 0…3 |
| 128000 ordered | 116 | 116 | 116 | 116 | 0.396 / 0.600 | 0…3 |
| 128000 shuffled | 73 | 73 | 0 | 73 | 0.515 / 1.000 | 0…3 |
| Chaos | 799 | 799 | 0 | 799 | 0.034 / 0.100 | -2…4 |

Across all 900 Chaos ticks, 900 fit the hypothetical guard and 0 were already canonical. Quad counts ranged 6443–7188; the proposed 32768 lower bound would deliberately leave all of them on the comparator path.

The raw audits retain every scene/layer/depth key and its population. The ordered/interleaved fixture has one scene, depth 0 and four integer layers 0–3. The shuffled label means deterministic round-robin interleaving, not a random permutation. Chaos has one scene, depth 0 and negative/positive integer layers; all 900 ticks, including warmup, are retained. Eligibility at the historical hypothetical guard does not establish a useful cutoff or speedup.

## Findings and limits

- Measured: large interleaved frames spend most of preparation in sorting. Gather is material but remains a separate cost. Ordered input is much cheaper to sort. Small unchanged Chaos has a much smaller absolute sort cost despite fitting the key shape.
- Large between-invocation variation affects several CPU stages and clean totals. Its cause was not established; these repetitions do not support a candidate acceptance claim or a causal estimate of diagnostic overhead. A later comparison must use fresh, contemporaneous baseline/candidate pairs and resolve or exceed the observed spread before accepting a result.
- Source inference: stable layer bucketing could replace repeated multi-key comparator calls for single-scene/common-depth identity input. It must preserve source-index tie order and therefore identical adjacent-texture runs. Public order mutations require the original comparator path.
- Prediction only: bounded counting/scatter could save CPU time on large interleaved frames. The eligibility scan is only one pass; counting, prefix calculation, scatter, copying back, allocations and integrated effects are unmeasured. No candidate speedup, GPU duration, FPS, capacity or consumer improvement is claimed.
- Historical black-hole values are context only. The engine revision matches, but these are tracked source fixtures with exact quad counts, deterministic interleaving and different key/submission distributions; no current black-hole replay was performed. Warmup/sample duration (5/10 seconds), no-backgrounding flags, backing sizes and benchmark build differ from the historical consumer experiment. Neither workload is a substitute for the other.
- Failed startup/build/cleanup/visibility attempts and an abruptly interrupted longer batch remain retained separately and are excluded from the accepted numerical baseline. The longer batch ended with exit 5 without finalization; the cause was not established. Its exact temporary profile had no surviving Chrome process when checked. No failed/partial attempt was relabeled accepted.

## Proposed algorithm for review

Recommend approval of a bounded experiment with a private stable counting-sort fast path in Frame.sort; keep scalar gathering unchanged. This is an algorithm proposal, not implementation approval or an established solution.

1. Preserve active-prefix trimming of order and textures. Immediate existing-comparator fallback for counts below a provisional 32768 or above a provisional 262144. These bounds deliberately cover measured 64K/128K frames and keep small Chaos on the existing path; they are conservative experiment choices, not measured optimal cutoffs.
2. For eligible sizes, scan the active prefix: order[i] must equal i, every scene must equal one finite scene key, every depth must equal one common finite depth, every layer must be a safe integer, and maxLayer-minLayer+1 must be a safe integer in 1…64. Negative layers use layer-minLayer. Any failure uses the exact existing comparator over the caller's active order; do not reconstruct or normalize mutated input.
3. Clear bounded bucket counts, count layers, prefix-sum to cursors, scatter source indices in increasing source-index order, then copy the resulting indices into the existing order array. One scene/common depth reduces the canonical key to layer then insertion index. Ascending source traversal makes ties stable. Never include texture in the key.
4. Frame owns reusable Uint32Array index scratch and bucket counts. Geometric index capacity capped at 262144 means at most 1,048,576 scratch bytes plus 256 bucket bytes per Frame (excluding object headers and existing arrays). Allocate/grow only after all guards pass. Reset retains scratch capacity; every operation reads/writes only the active prefix and clears the active buckets. Existing order object identity is preserved.
5. Total extra work is an eligibility scan, count pass, bounded prefix pass, stable scatter and copy-back: roughly four full index/key passes plus O(layer range). The measured scan is only the first. Fallback after a late failure can pay a whole scan before the original sort. Already-ordered large frames can regress because native sorting is already inexpensive; this is an explicit comparison case and may rule out the candidate or require a separately reviewed narrower guard.

Alternatives: retain the comparator if integrated results fail; raise the small-frame cutoff after measurement; consider broader radix/composite sorting only as a separate investigation if diverse scene/depth evidence warrants it. A general already-canonical skip is not supported by the unchanged Chaos audit. No new public hints, consumer changes, texture regrouping or gather/layout changes are proposed.

## Post-approval comparison and correctness plan

- Only after written approval: compare the exact current baseline with the approved candidate, in alternating baseline/candidate order across fresh browsers and at least three retained pairs. Keep clean complete-CPU/cadence results separate from boundary attribution. Repeat the tracked 64K/128K ordered and interleaved cases and unchanged Chaos; sweep smaller counts around 4K/8K/16K/32K and retain mixed/fallback cases to decide the threshold. The provisional upper bound requires boundary correctness and allocation checks; no larger-workload performance claim follows from this investigation.
- Require useful targeted-stage savings beyond the observed run spread and consistent complete-CPU benefit, with no worse tail/cadence outcomes. If assessing game overload/dropped ticks, add an unchanged BrowserGame-host workload after approval; the deterministic tick-per-RAF replay cannot establish that outcome. Do not sum nested sort and prepare or interpret CPU queue calls as GPU duration.
- Compare exact sorted index arrays and exact uploaded bytes with the unchanged comparator. Cover transparent overlap and mixed adjacent textures, scene/layer/depth ties, negative layers/depths, common finite fractional depth, fractional layers, differing fractional depths, NaN/Infinity, unsafe integers, wide ranges and boundary span sizes.
- Cover public order permutations/duplicates/holes, repeated sort without reset, reset/reuse, changing minimum layer, empty/shrinking frames, threshold/cap boundaries and scratch growth/stale tails. Preserve validation/growth failure ordering and buffer limits; existing focused packing/renderer tests remain required. Use software GPU for deterministic correctness if useful and hardware WebGPU for performance.

## Validation and documentation

25 focused tests passed (packing/renderer, investigation outcomes, summaries, visibility and order diagnostics). Tooling typechecks and the browser benchmark TypeScript target passed. Per-count ordering screenshots match byte-for-byte across clean, diagnostic and audit modes, and across ordered/interleaved input; this is automated rendered-output evidence, not manual acceptance or a replacement for future exact index/upload checks. Final formatting, source-scope and artifact checks are recorded in validation.txt. No authoritative document or public API changes are intended or applied. Remaining decisions: written algorithm/scope approval before any prototype or replacement benchmark; final thresholds depend on the approved comparison.

## Reproduction and retained artifacts

Use the complete diagnostic source overlay and baseline revision in this evidence bundle. From a baseline checkout with its existing dependencies, overlay diagnostic-source at the repository root. Run the existing runner only; no benchmark framework was added.

```powershell
$env:TEMP = Join-Path (Get-Location) 'out/task-temp'
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Force $env:TEMP | Out-Null
$env:NGNE_MINIFY = '1'
$env:NGNE_NO_BACKGROUNDING = '1'
$env:NGNE_WARMUP_SECONDS = '5'
$env:NGNE_DURATION_SECONDS = '10'
$env:NGNE_PREPARATION_STAGES = '0' # clean; use '1' for separate diagnostic invocations
$cases = 'workload=ordering&count=64000&order=ordered&detail=0;workload=ordering&count=64000&order=shuffled&detail=0;workload=ordering&count=128000&order=ordered&detail=0;workload=ordering&count=128000&order=shuffled&detail=0;workload=chaos&detail=0'
node node_modules/tsx/dist/cli.mjs tooling/suites/benchmarks/rendering/investigate.ts . tooling/suites/benchmarks/rendering/browser/index.html $cases 1
# Repeat each mode in three separate invocations, reversing the query order between invocations.
# Audit separately: stages=0, warmup=1, duration=2; append &audit=1 to each case.
node node_modules/tsx/dist/cli.mjs --test tooling/tests/order-diagnostics.test.ts tooling/tests/investigation-summary.test.ts tooling/tests/investigation-case.test.ts tests/frame-layout.test.ts tests/webgpu-renderer.test.ts
npm.cmd run typecheck:tooling
node node_modules/typescript/bin/tsc -p tooling/suites/benchmarks/rendering/browser/tsconfig.json
```

summary.json retains per-run statistics, tails, source identities, growth records and audit summaries. Each accepted run has untouched raw samples, key distributions where selected, screenshots, browser/GPU details, module/build identities, exact transformed renderer text, complete harness-source snapshots, cleanup outcomes and an exact artifact inventory. analyze.ts validates schemas/run identities, all inventory hashes and summaries against raw samples; analysis.log is its console output. SHA256SUMS covers the shareable bundle; run roots below identify the original local evidence.

To recheck the archived raw data, place analyze.ts and report.mjs under the repository's out/profiles/frame-sort-investigation-2026-10-15 directory, run the analyzer with each extracted runs/<run-id> root as an argument, then run report.mjs. This uses the existing evidence validators at the recorded baseline plus the supplied overlay.

- 2026-10-15T16-06-13.010Z-performance-investigation-1c89700c-560a-4d50-9621-a09701546041: clean/audit; artifact-inventory SHA-256 fd8d28269dfcf58466474c63153c2939d4d0c099dc1e83c0f8335d6d9e5f3ee4.
- 2026-10-15T16-08-57.375Z-performance-investigation-80a10051-dfbc-4592-9abf-8c0867627190: stage-timed; artifact-inventory SHA-256 516b2eff0b7566e224891a62f9ef4c11d6a483bcee511a932488a72c44442243.
- 2026-10-15T16-10-57.500Z-performance-investigation-4e4221a2-8349-4229-b33f-e5ef3488379d: clean/audit; artifact-inventory SHA-256 6a5a10f8cd30f3b6d1d15ec853d1c38f4a9233f44f4bce2a7d17673929791b61.
- 2026-10-15T16-12-37.565Z-performance-investigation-538ef32c-7b8c-4a19-9b87-f05aad3f5e97: stage-timed; artifact-inventory SHA-256 9dd040d7c23fe5eb21c6f8191a829162cdd96855df1fee48007724f59063f582.
- 2026-10-15T16-14-24.010Z-performance-investigation-06545146-653f-45d7-80f3-c3ce09d27356: clean/audit; artifact-inventory SHA-256 543ac43494cf8b0fd7b273adf8705b0adcbc460a2fd2f917f36cbc33a8f3a4f9.
- 2026-10-15T16-17-16.497Z-performance-investigation-2bcb49f0-d6f9-4bfa-8384-1b77e6cd9973: stage-timed; artifact-inventory SHA-256 a1b7bee00dac4c205c15fa4837f11ca6cb1953d0791462e90f598870167197ef.
- 2026-10-15T16-19-03.887Z-performance-investigation-bcecd17f-717d-42b5-981e-a9e58db34a83: clean/audit; artifact-inventory SHA-256 623dbc4bdeb6d5cbb910044aff680890b06d4a4dcfa5b286c8a7ac0669cb7207.
