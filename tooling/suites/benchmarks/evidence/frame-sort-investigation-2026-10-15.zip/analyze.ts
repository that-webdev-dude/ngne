import { readFileSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { contained, hash, verifyArtifactInventory } from "../../../tooling/evidence/identity.js";
import { readManifest, readResult, readArtifacts, readHeader } from "../../../tooling/evidence/schema.js";
import { summarizeFrames, distribution } from "../../../tooling/suites/benchmarks/rendering/investigation-summary.js";

const json = (path: string) => JSON.parse(readFileSync(path, "utf8"));
const roots = process.argv.slice(2).map(path => resolve(path));
if (!roots.length) throw Error("Supply exact accepted run roots");
const results = roots.map(root => {
    const evidence = join(root, "evidence");
    const manifest = readManifest(json(join(evidence, "manifest.json")));
    const result = readResult(json(join(evidence, "result.json")));
    const inventory = readArtifacts(json(join(evidence, "artifacts.json")));
    if (!result.accepted || result.evidence !== "complete" || result.cleanup !== "passed")
        throw Error(`Rejected run: ${root}`);
    if (inventory.runId !== manifest.runId || result.runId !== manifest.runId) throw Error("Cross-run evidence");
    verifyArtifactInventory(evidence, inventory.files.map(file => file.path));
    for (const file of inventory.files) {
        const bytes = readFileSync(contained(evidence, file.path));
        if (bytes.length !== file.bytes || hash(bytes) !== file.sha256) throw Error(`Changed artifact: ${file.path}`);
    }
    const cases = result.stages.filter(stage => /^r\d+-c\d+$/.test(stage.id)).map(stage => {
        const m = json(join(evidence, "stages", stage.id, "measurements.json"));
        if (readHeader(m, "measurements").runId !== manifest.runId) throw Error("Cross-run measurement");
        if (m.errors.length || m.error || m.measuredVisibility === false || m.adapter.isFallbackAdapter)
            throw Error("Invalid measurement");
        if (JSON.stringify(summarizeFrames(m)) !== JSON.stringify(m.summary)) throw Error("Summary differs from raw data");
        const c = (name: string) => m.columns.indexOf(name);
        const sample = m.samples.filter((row: number[]) => row[0] >= m.begin && row[0] < m.end);
        const sampledTicks = new Set(sample.map((row: number[]) => row[c("tick")]));
        const audits = m.audits.filter((a: {tick: number}) => sampledTicks.has(a.tick));
        const growthEvents = m.samples.flatMap((row: number[], index: number) => {
            const previous = index ? m.samples[index - 1][c("growths")] : 0;
            return row[c("growths")] > previous ? [{
                tick: row[c("tick")], time: row[0], inWindow: row[0] >= m.begin && row[0] < m.end,
                count: row[c("quads")], growthMs: row[c("growth")],
            }] : [];
        });
        return {
            stage: stage.id, query: m.query, repeat: m.repeat, metadata: m.metadata,
            begin: m.begin, end: m.end, summary: m.summary,
            browser: m.version, adapter: m.adapter, gpu: m.gpu.gpu.devices,
            measuredVisibility: m.measuredVisibility, visibilityEvents: m.visibilityEvents,
            screenshotSha256: hash(readFileSync(join(evidence, "stages", stage.id, "frame.png"))),
            growthEvents,
            audit: audits.length ? {
                frames: audits.length,
                identityInput: audits.filter((a: {identity: boolean}) => a.identity).length,
                canonicalIdentity: audits.filter((a: {canonicalIdentity: boolean}) => a.canonicalIdentity).length,
                eligible4096x64: audits.filter((a: {eligible4096x64: boolean}) => a.eligible4096x64).length,
                scanMs: distribution(audits.map((a: {scanMs: number}) => a.scanMs)),
                all900Frames: m.audits.length,
                allEligible: m.audits.filter((a: {eligible4096x64: boolean}) => a.eligible4096x64).length,
                allCanonicalIdentity: m.audits.filter((a: {canonicalIdentity: boolean}) => a.canonicalIdentity).length,
                allCount: distribution(m.audits.map((a: {count: number}) => a.count)),
                count: distribution(audits.map((a: {count: number}) => a.count)),
                minLayer: Math.min(...audits.map((a: {minLayer: number}) => a.minLayer)),
                maxLayer: Math.max(...audits.map((a: {maxLayer: number}) => a.maxLayer)),
                keySets: [...new Set(audits.map((a: {keys: Record<string, number>}) => Object.keys(a.keys).sort().join(",")))],
            } : null,
        };
    });
    return {root, runId: manifest.runId, source: manifest.provenance, policy: manifest.policy,
        environment: manifest.environment, cases, artifactsSha256: hash(readFileSync(join(evidence, "artifacts.json")))};
});
writeFileSync(new URL("./summary.json", import.meta.url), JSON.stringify(results, null, 2) + "\n");
for (const run of results) for (const c of run.cases) console.log(JSON.stringify({
    run: run.runId, query: c.query, repeat: c.repeat, frames: c.summary.frames,
    mean: Object.fromEntries(Object.entries(c.summary.metrics).map(([key, value]) => [key, (value as {mean: number}).mean])),
    p95cpu: c.summary.metrics.cpu.p95, p99cpu: c.summary.metrics.cpu.p99,
    p95cadence: c.summary.metrics.cadence.p95, p99cadence: c.summary.metrics.cadence.p99,
    audit: c.audit, growthEvents: c.growthEvents,
}));
