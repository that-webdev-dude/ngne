# performance-investigation

Run: 2026-10-15T15-58-09.371Z-performance-investigation-d1c72970-4a2b-420d-9452-71bc4de79ae5
Accepted: false

- scenario: [measurement-identities] Diagnostic anchor changed: prepare(frame: Frame): void {
file: C:/Users/jfabi/Documents/Projects/tests/ngne/src/quad-renderer.ts

Execution: failed; correctness: failed; budgets: not evaluated; cleanup: passed; evidence: complete.

Evidence applies only to the selected suite and recorded environment. It does not establish controlled run comparability or manual visual/audio confirmation. Compatibility was not selected.

- build: failed, correctness failed, budgets not evaluated

[Manifest](manifest.json) · [Result](result.json)
