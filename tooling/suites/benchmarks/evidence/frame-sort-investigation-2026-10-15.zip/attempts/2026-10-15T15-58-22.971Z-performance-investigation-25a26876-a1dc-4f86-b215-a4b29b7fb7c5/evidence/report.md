# performance-investigation

Run: 2026-10-15T15-58-22.971Z-performance-investigation-25a26876-a1dc-4f86-b215-a4b29b7fb7c5
Accepted: false

- scenario: browser: exited before workload completed (4294930433)
- cleanup: r1-c1 browser terminate/verify: browser PID 28008: terminate/verify failed: Command failed: powershell.exe -NoProfile -NonInteractive -Command Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,@{Name='Born';Expression={$_.CreationDate.ToUniversalTime().ToString('o')}} | ConvertTo-Json -Compress
Get-CimInstance : Access to a CIM resource was not available to the client.
At line:1 char:1
+ Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcess ...
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : NotSpecified: (:) [Get-CimInstance], CimException
    + FullyQualifiedErrorId : Microsoft.Management.Infrastructure.CimException,Microsoft.Management.Infrastructure.Cim 
   Cmdlets.GetCimInstanceCommand
 


Execution: failed; correctness: failed; budgets: not evaluated; cleanup: failed; evidence: complete.

Evidence applies only to the selected suite and recorded environment. It does not establish controlled run comparability or manual visual/audio confirmation. Compatibility was not selected.

- build: completed, correctness passed, budgets not evaluated
- r1-c1: failed, correctness failed, budgets not evaluated

[Manifest](manifest.json) · [Result](result.json)
