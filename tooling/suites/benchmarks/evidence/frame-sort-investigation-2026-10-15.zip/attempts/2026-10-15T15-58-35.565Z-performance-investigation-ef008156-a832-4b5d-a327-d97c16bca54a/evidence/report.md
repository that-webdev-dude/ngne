# performance-investigation

Run: 2026-10-15T15-58-35.565Z-performance-investigation-ef008156-a832-4b5d-a327-d97c16bca54a
Accepted: false

- cleanup: r1-c1 browser terminate/verify: browser PID 16768: terminate/verify failed: browser PID 16768: shutdown terminate: Command failed: taskkill.exe /PID 16768 /PID 19072 /PID 14280 /PID 37484 /PID 27340 /PID 36504 /PID 36820 /PID 31492 /PID 21260 /PID 9244 /PID 31476 /PID 29508 /T
ERROR: The process with PID 27340 (child process of PID 16768) could not be terminated.
Reason: This process can only be terminated forcefully (with /F option).
ERROR: The process with PID 36504 (child process of PID 16768) could not be terminated.
Reason: This process can only be terminated forcefully (with /F option).
ERROR: The process with PID 36820 (child process of PID 16768) could not be terminated.
Reason: This process can only be terminated forcefully (with /F option).
ERROR: The process with PID 31492 (child process of PID 16768) could not be terminated.
Reason: This process can only be terminated forcefully (with /F option).
ERROR: The process with PID 21260 (child process of PID 16768) could not be terminated.
Reason: This process can only be terminated forcefully (with /F option).
ERROR: The process with PID 9244 (child process of PID 16768) could not be terminated.
Reason: This process can only be terminated forcefully (with /F option).
ERROR: The process with PID 31476 (child process of PID 16768) could not be terminated.
Reason: This process can only be terminated forcefully (with /F option).
ERROR: The process with PID 29508 (child process of PID 16768) could not be terminated.
Reason: This process can only be terminated forcefully (with /F option).
ERROR: The process with PID 16768 (child process of PID 1508) could not be terminated.
Reason: One or more child processes of this process were still running.
, force; surviving PID(s): 30232

Execution: completed; correctness: passed; budgets: not evaluated; cleanup: failed; evidence: complete.

Evidence applies only to the selected suite and recorded environment. It does not establish controlled run comparability or manual visual/audio confirmation. Compatibility was not selected.

- build: completed, correctness passed, budgets not evaluated
- r1-c1: completed, correctness passed, budgets not evaluated

[Manifest](manifest.json) · [Result](result.json)
