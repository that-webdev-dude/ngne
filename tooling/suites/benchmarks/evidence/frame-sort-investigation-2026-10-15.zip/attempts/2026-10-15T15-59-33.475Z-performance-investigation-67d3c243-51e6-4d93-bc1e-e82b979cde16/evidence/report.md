# performance-investigation

Run: 2026-10-15T15-59-33.475Z-performance-investigation-67d3c243-51e6-4d93-bc1e-e82b979cde16
Accepted: false

- scenario: Fixture startup: [{"timestamp":1792079982980.096,"exceptionDetails":{"exceptionId":1,"text":"Uncaught","lineNumber":83,"columnNumber":3412,"scriptId":"6","url":"http://127.0.0.1:56977/assets/index-CcYHlGIu.js","stackTrace":{"callFrames":[{"functionName":"prepare","scriptId":"6","url":"http://127.0.0.1:56977/assets/index-CcYHlGIu.js","lineNumber":83,"columnNumber":3412},{"functionName":"E","scriptId":"6","url":"http://127.0.0.1:56977/assets/index-CcYHlGIu.js","lineNumber":83,"columnNumber":32028}]},"exception":{"type":"object","subtype":"error","className":"Error","description":"Error: Texture is not ready: ships\n    at Object.prepare (http://127.0.0.1:56977/assets/index-CcYHlGIu.js:84:3413)\n    at E (http://127.0.0.1:56977/assets/index-CcYHlGIu.js:84:32029)","objectId":"-3702436125841459975.2.1","preview":{"type":"object","subtype":"error","description":"Error: Texture is not ready: ships\n    at Object.prepare (http://127.0.0.1:56977/assets/index-CcYHlGIu.js:84:3413)\n    at E (http://127.0.0.1:56977/assets/index-CcYHlGIu.js:84:32029)","overflow":false,"properties":[{"name":"stack","type":"string","value":"Error: Texture is not ready: ships\n    at Object.p…27.0.0.1:56977/assets/index-CcYHlGIu.js:84:32029)"},{"name":"message","type":"string","value":"Texture is not ready: ships"}]}},"executionContextId":2}}]

Execution: failed; correctness: failed; budgets: not evaluated; cleanup: passed; evidence: complete.

Evidence applies only to the selected suite and recorded environment. It does not establish controlled run comparability or manual visual/audio confirmation. Compatibility was not selected.

- build: completed, correctness passed, budgets not evaluated
- r1-c1: completed, correctness passed, budgets not evaluated
- r1-c2: failed, correctness failed, budgets not evaluated

[Manifest](manifest.json) · [Result](result.json)
