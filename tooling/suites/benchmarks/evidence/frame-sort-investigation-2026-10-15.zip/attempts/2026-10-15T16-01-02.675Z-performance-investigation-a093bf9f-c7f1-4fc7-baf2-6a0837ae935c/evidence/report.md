# performance-investigation

Run: 2026-10-15T16-01-02.675Z-performance-investigation-a093bf9f-c7f1-4fc7-baf2-6a0837ae935c
Accepted: false

- scenario: Invalid sample: {"visibility":"visible","hidden":true,"error":"","errors":[]}

Execution: failed; correctness: failed; budgets: not evaluated; cleanup: passed; evidence: complete.

Evidence applies only to the selected suite and recorded environment. It does not establish controlled run comparability or manual visual/audio confirmation. Compatibility was not selected.

- build: completed, correctness passed, budgets not evaluated
- r1-c1: failed, correctness failed, budgets not evaluated

[Manifest](manifest.json) · [Result](result.json)
