import {cpSync,existsSync,mkdirSync,readFileSync,readdirSync,writeFileSync} from 'node:fs';
import {join,resolve,relative,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root=process.cwd(), here=fileURLToPath(new URL('.',import.meta.url));
const summary=JSON.parse(readFileSync(join(here,'summary.json'),'utf8'));
const bundle=join(here,'bundle');
const zip=join(root,'tooling/suites/benchmarks/evidence/frame-sort-investigation-2026-10-15.zip');
if(existsSync(bundle)||existsSync(zip))throw Error('Refuse to overwrite retained evidence');
mkdirSync(bundle);
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const changed=execFileSync('git',['diff','--name-only'],{encoding:'utf8'}).trim().split(/\r?\n/).filter(Boolean);
const untracked=execFileSync('git',['ls-files','--others','--exclude-standard'],{encoding:'utf8'}).trim().split(/\r?\n/).filter(Boolean);
const sources=[...new Set([...changed,...untracked])];
if(sources.some(path=>!path.startsWith('tooling/')||!path.endsWith('.ts')))throw Error('Unexpected diagnostic source scope');
const sourceHashes={};
for(const path of sources){const target=join(bundle,'diagnostic-source',path);mkdirSync(resolve(target,'..'),{recursive:true});cpSync(join(root,path),target);sourceHashes[path]=sha(readFileSync(target));}
const included=[];
for(const run of summary){cpSync(run.root,join(bundle,'runs',run.runId),{recursive:true});included.push({id:run.runId,role:run.policy.stages?'stage baseline':run.cases[0].metadata.audit?'audit':'clean baseline'});}
const selected=new Set(summary.map(run=>run.runId));
const attempts=readdirSync(join(root,'out/runs')).filter(name=>name.startsWith('2026-10-15T')&&name>='2026-10-15T15-58-'&&name.includes('performance-investigation')&&!selected.has(name));
for(const name of attempts){cpSync(join(root,'out/runs',name),join(bundle,'attempts',name),{recursive:true});included.push({id:name,role:'excluded smoke, failed or partial attempt; inspect original result'});}
for(const name of ['REPORT.md','summary.json','analysis.log','analyze.ts','report.mjs','pack.mjs','validation.txt','validation-tests.txt','validation-tooling.txt','validation-browser-typecheck.txt','validation-format.txt'])cpSync(join(here,name),join(bundle,name));
cpSync(join(root,'LICENSE'),join(bundle,'LICENSE'));
writeFileSync(join(bundle,'bundle-manifest.json'),JSON.stringify({baseline:'4f94758ee110e32c394ea72d7450a400d27983c6',branch:'codex/gh37-frame-sort-investigation',sourceHashes,runs:included,optimizationImplemented:false,documentationChanged:false},null,2)+'\n');
const files=[];
function walk(dir){for(const item of readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){const path=join(dir,item.name);if(item.isSymbolicLink())throw Error('Linked evidence');if(item.isDirectory())walk(path);else if(item.isFile())files.push({path:relative(bundle,path).split(sep).join('/'),sha256:sha(readFileSync(path))});else throw Error('Unexpected file type');}}
walk(bundle);
writeFileSync(join(bundle,'SHA256SUMS'),files.map(file=>`${file.sha256}  ${file.path}`).join('\n')+'\n');
execFileSync('tar.exe',['-a','-cf',zip,'-C',bundle,'.'],{stdio:'inherit'});
const checksum=sha(readFileSync(zip));
writeFileSync(`${zip}.sha256`,`${checksum}  frame-sort-investigation-2026-10-15.zip\n`);
console.log(JSON.stringify({zip,sha256:checksum,files:files.length+1,acceptedRuns:summary.length,excludedAttempts:attempts.length,sourceHashes},null,2));
