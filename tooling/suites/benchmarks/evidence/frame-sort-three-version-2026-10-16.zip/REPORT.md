# Revised frame sorting comparison

Evidence date: 2026-10-16. Original source: 4f94758ee110e32c394ea72d7450a400d27983c6. Current candidate checkpoint: f447498b535c1beb02184fc047fe703436fc80a9. Revised source is uncommitted on the same branch. No push.

Targeted revision experiment: PASS. The originally observed ordered late-depth regression is removed, and the large interleaved gains are preserved. This is not a universal zero-regression pass for all fallback inputs.

Across three fresh rotated clean rounds, the revised candidate reduced full CPU on the originally failing 64K ordered late-depth case by 12.7-15.9% versus the original comparator and 15.0-17.9% versus the committed candidate. Its preparation means were 1.147-1.176 ms, below original 1.719-1.800 ms and current 1.806-1.909 ms. Diagnostic complete-sort means were 0.196-0.205 ms versus original 0.758-0.770 ms and current 0.875-0.899 ms. The committed candidate's duplicated scan-plus-sort cost is avoided by proving canonical order. Revised interleaved full CPU reductions versus original were 48.9-54.6% at 64K and 57.6-60.4% at 128K. Against the committed candidate, clean full CPU changed -3.8% to +0.6% at 64K and -2.3% to +3.2% at 128K, with overlapping invocation ranges and no consistent mean-time loss. Large-workload CPU/cadence tails remain substantially better than original; small tail differences against current vary by run. Ordered eligible control means also improved versus original in every round. Small/Chaos control ranges overlap and do not establish an attributable speedup or universal zero-cost guarantee.

## Implementation

The revision tracks nondecreasing layers while checking the existing eligibility conditions. Once an inversion is found, it stops the extra ordered comparison. Already-ordered eligible input returns after the scan without allocating counting-sort scratch. If a different depth is encountered while the checked prefix remains ordered, a bounded helper proves the remaining identity indices, common finite scene, safe-integer layers, finite depths, canonical layer/depth order, and span ≤64. A failed proof uses the exact original comparator without rewriting input. The first differing depth is necessarily after index zero. Packing, gathering, upload layout and public API remain unchanged; scratch caps remain unchanged.

## Clean full CPU

Cells list three independent invocation means in round order, ms/frame. Changes compare the same round; negative means faster. No frames are pooled across invocations.

| Workload | Original | Current | Revised | Revised vs original | Revised vs current |
| --- | ---: | ---: | ---: | ---: | ---: |
| 64000 interleaved | 7.337 / 7.998 / 8.159 | 3.805 / 3.688 / 3.847 | 3.746 / 3.709 / 3.700 | -48.9% / -53.6% / -54.6% | -1.6% / 0.6% / -3.8% |
| 128000 interleaved | 13.809 / 14.838 / 15.199 | 5.767 / 5.695 / 6.182 | 5.858 / 5.880 / 6.042 | -57.6% / -60.4% / -60.2% | 1.6% / 3.2% / -2.3% |
| 64000 ordered / late-depth | 4.535 / 4.712 / 4.847 | 4.663 / 4.666 / 4.980 | 3.956 / 3.965 / 4.089 | -12.7% / -15.9% / -15.6% | -15.1% / -15.0% / -17.9% |
| 64000 ordered | 4.664 / 4.514 / 4.543 | 4.323 / 4.109 / 4.098 | 3.673 / 3.914 / 3.786 | -21.2% / -13.3% / -16.7% | -15.0% / -4.7% / -7.6% |
| 128000 ordered | 7.708 / 7.578 / 7.659 | 6.100 / 6.601 / 6.725 | 5.957 / 5.951 / 5.842 | -22.7% / -21.5% / -23.7% | -2.3% / -9.9% / -13.1% |
| Chaos | 1.886 / 1.738 / 1.682 | 1.704 / 1.799 / 1.848 | 1.672 / 1.727 / 1.735 | -11.3% / -0.6% / 3.1% | -1.9% / -4.0% / -6.1% |
| 16384 interleaved | 2.513 / 2.646 / 2.480 | 2.655 / 2.569 / 2.463 | 2.397 / 2.528 / 2.597 | -4.6% / -4.5% / 4.7% | -9.7% / -1.6% / 5.4% |
| 64000 ordered / late-depth-down | 5.512 / 5.309 / 5.350 | 5.598 / 5.003 / 5.685 | 5.230 / 5.641 / 5.415 | -5.1% / 6.3% / 1.2% | -6.6% / 12.8% / -4.7% |
| 64000 ordered / wide-layers | 5.191 / 5.133 / 5.230 | 5.591 / 5.155 / 5.627 | 5.310 / 5.285 / 5.116 | 2.3% / 3.0% / -2.2% | -5.0% / 2.5% / -9.1% |
| 64000 interleaved / mixed-depth | 12.880 / 12.435 / 12.952 | 12.149 / 11.449 / 12.216 | 11.805 / 11.911 / 11.967 | -8.3% / -4.2% / -7.6% | -2.8% / 4.0% / -2.0% |

## Complete sort attribution

Separate diagnostic runs; sort includes active-prefix trimming, eligibility/ordered checks, tail proof or fallback, scratch allocation when needed, bucket work, scatter and copy-back. Sort is nested in prepare and full CPU; never sum those stages.

| Workload | Original sort | Current sort | Revised sort | Revised vs original | Revised vs current |
| --- | ---: | ---: | ---: | ---: | ---: |
| 64000 interleaved | 4.521 / 4.672 / 4.659 | 0.350 / 0.343 / 0.337 | 0.341 / 0.338 / 0.363 | -92.5% / -92.8% / -92.2% | -2.8% / -1.7% / 7.9% |
| 128000 interleaved | 9.056 / 9.421 / 9.422 | 0.616 / 0.639 / 0.635 | 0.653 / 0.656 / 0.603 | -92.8% / -93.0% / -93.6% | 6.0% / 2.6% / -5.0% |
| 64000 ordered / late-depth | 0.758 / 0.770 / 0.765 | 0.875 / 0.881 / 0.899 | 0.196 / 0.199 / 0.205 | -74.2% / -74.2% / -73.2% | -77.7% / -77.4% / -77.2% |

## Clean tails

Triplets are independent round values in ms/frame. Each workload has one row per source version. All other metrics and controls remain in summary.json.

| Workload | Version | CPU p95 | CPU p99 | Cadence p95 | Cadence p99 |
| --- | --- | ---: | ---: | ---: | ---: |
| 64000 interleaved | original | 8.100 / 8.900 / 9.100 | 8.700 / 9.500 / 10.000 | 8.300 / 9.100 / 9.400 | 9.100 / 9.800 / 10.300 |
| 64000 interleaved | current | 4.500 / 4.400 / 4.600 | 5.000 / 4.900 / 5.400 | 7.200 / 7.200 / 7.200 | 7.400 / 7.400 / 7.400 |
| 64000 interleaved | revised | 4.400 / 4.400 / 4.400 | 5.000 / 5.200 / 5.500 | 7.300 / 7.200 / 7.500 | 7.600 / 7.400 / 7.800 |
| 128000 interleaved | original | 14.900 / 16.300 / 16.900 | 16.000 / 17.400 / 18.300 | 15.100 / 16.500 / 17.100 | 16.100 / 17.700 / 18.600 |
| 128000 interleaved | current | 7.000 / 6.600 / 7.400 | 7.600 / 7.500 / 9.300 | 7.400 / 7.200 / 7.600 | 7.900 / 7.800 / 9.600 |
| 128000 interleaved | revised | 7.000 / 7.200 / 7.200 | 7.800 / 8.200 / 7.800 | 7.300 / 7.500 / 7.500 | 8.000 / 8.400 / 8.200 |
| 64000 ordered / late-depth | original | 5.200 / 5.300 / 5.700 | 5.800 / 5.900 / 6.300 | 7.200 / 7.200 / 7.200 | 7.300 / 7.300 / 7.300 |
| 64000 ordered / late-depth | current | 5.400 / 5.400 / 5.800 | 6.000 / 6.300 / 6.300 | 7.200 / 7.300 / 7.200 | 7.300 / 8.000 / 7.300 |
| 64000 ordered / late-depth | revised | 4.700 / 4.600 / 4.900 | 6.000 / 5.800 / 6.000 | 7.200 / 7.200 / 7.200 | 7.400 / 7.400 / 7.300 |
| 64000 ordered / late-depth-down | original | 7.700 / 7.100 / 7.000 | 8.800 / 8.800 / 8.600 | 8.000 / 7.400 / 7.400 | 9.100 / 9.100 / 8.900 |
| 64000 ordered / late-depth-down | current | 7.600 / 6.000 / 7.700 | 8.700 / 7.800 / 9.300 | 7.900 / 7.200 / 8.000 | 9.100 / 7.900 / 9.600 |
| 64000 ordered / late-depth-down | revised | 7.200 / 8.300 / 7.200 | 8.200 / 9.200 / 8.700 | 7.600 / 8.500 / 7.500 | 8.500 / 9.500 / 9.000 |

## Method and environment

- Three contemporaneous source versions, each run three times per mode. Latin rotation: original→current→revised, current→revised→original, revised→original→current. Workload order reverses in round two. Each case owns a fresh browser/profile and closes it before the next case. Core clean and diagnostic cases: 5 seconds warmup, 10 seconds sampled. Controls: 2 seconds warmup, 4 seconds sampled. Chaos is an unchanged 900-tick replay, with ticks 1–101 warmup and 102–900 sampled, one tick per RAF.
- Exact renderer snapshots are substituted at build time for all three versions. Analyzer verifies each compiled renderer hash against its source file and journal identity and asserts every non-renderer module input is identical across all runs. All builds minified; separate clean and boundary-timed diagnostic modes; no CPU/allocation profiler.
- win32 10.0.26200 x64; Node v24.15.0; 12th Gen Intel(R) Core(TM) i7-12650H; Vite 7.3.6; Chrome/155.0.8059.82; hardware adapter {"vendor":"intel","architecture":"gen-12lp","device":"","description":"","isFallbackAdapter":false,"dpr":1.25,"viewport":[1487,788]}. Requested window 1500×1100, ordering canvas 1440×900, Chaos 640×400. No-backgrounding flags retained. Power/thermal state uncontrolled.
- 27 accepted invocations, 117 valid case windows; all measured windows visible, hardware WebGPU adapter checks passed, all owned process/profile cleanup passed. 0 sampled GPU instance-buffer growth events. Cold samples are retained separately; steady measurements do not quantify initial scratch-allocation cost. User confirmed Claude continued holding local Playwright and heavy runs. No tests/builds ran concurrently with timing.
- Full CPU measures synchronous update/packing/preparation/encode/submit-call time, not asynchronous GPU duration. RAF cadence is not a game-host dropped-tick count. No consumer, device-wide, manual visual, universal FPS or above-128K performance claim follows. Interleaved means deterministic four-layer round-robin, not a random permutation.

## Correctness and retained evidence

32 focused tests passed; full build and engine/tooling/browser TypeScript targets passed. Headless software-WebGPU checks passed, including 32K ordered depth-tail, actual inversion and NaN comparisons against native-comparator pixel/index/texture-run results. Software correctness is distinct from the hardware timing evidence. Tests also cover existing fallback mutation semantics, exact upload bytes, scratch caps/reuse, count/span boundaries and reset/shrink. The first sandboxed focused-suite attempt hit an atomic-rename EPERM in a tooling test; the unchanged test rerun with required filesystem access passed. Failed attempt retained.

summary.json retains every run mean, p50/p95/p99, source identity, cold sample, growth count and run root. Raw runs retain samples, build/module/source snapshots, screenshots, adapter/version observations and cleanup records. analyze.ts verifies schemas, inventories, file hashes, raw-summary recomputation, visibility, hardware adapter, cleanup, active upload size and exact source versions. A run's accepted flag means evidence validity, not automatic performance acceptance.

The finite, already-canonical late-depth case is fixed. Genuine disorder and unsupported keys still use the exact comparator after eligibility work. For the final negative-depth inversion, revised versus original full CPU changed -5.1% / +6.3% / +1.2%; preparation changed -0.1% / +8.2% / +5.5%, with overlapping invocation ranges. Wide ordered layers also retained a small repeatable preparation tax: +3.1% / +6.7% / +2.1%, while full CPU changed +2.3% / +3.0% / -2.2%. Therefore accepting this revision as a universal zero-regression replacement is not justified. The targeted fix and preserved large-workload gains are supported; broader fallback guarantees remain outside that conclusion. The revised engine/test/fixture changes are left uncommitted on the same branch after the requested checkpoint f447498; no additional commit or push, issue mutation, publication, consumer edit or authoritative-document change was performed. One revised control host invocation exited unexpectedly with code 3221226505 before its sixth case; cause unknown. Its whole partial invocation is excluded, raw files and logs are retained, no live task-owned Chrome remained, its newly created orphan profile was removed within the verified task temp root, and the full unchanged-source invocation was rerun successfully. Successful-run cleanup and this excluded attempt remain distinct.

## Reproduction

Overlay the archived source-overlay on the original recorded revision with its dependencies. Copy measure.mjs and the three *-renderer.ts snapshots into a fresh ignored out/profiles directory. From the repository root, run node <fresh>/measure.mjs <core|stages|controls> <start-index> <exclusive-end-index>. Indices 0..8 select the three rotated rounds; use small invocations, at most three indices each, to preserve completed evidence if a supervisor is interrupted. The driver refuses to overwrite retained attempts. A quiet local machine and hardware WebGPU are required for timings.

To reanalyze archived evidence, put analyze.ts under out/profiles/<report-folder> in that source checkout and run node node_modules/tsx/dist/cli.mjs out/profiles/<report-folder>/analyze.ts <extracted-archive-root>. The archive includes all three renderer snapshots, journal, raw runs, source overlay, checksums and scripts.
