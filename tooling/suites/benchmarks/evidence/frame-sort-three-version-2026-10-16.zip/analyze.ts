import { readFileSync, writeFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { contained, hash, verifyArtifactInventory } from '../../../tooling/evidence/identity.js';
import { readManifest, readResult, readArtifacts, readHeader } from '../../../tooling/evidence/schema.js';
import { summarizeFrames } from '../../../tooling/suites/benchmarks/rendering/investigation-summary.js';
const folder = dirname(fileURLToPath(import.meta.url));
const archive = process.argv[2] ? resolve(process.argv[2]) : undefined;
const records = readFileSync(join(archive ?? folder,'runs.jsonl'),'utf8').trim().split('\n').map(line=>JSON.parse(line));
const rows: Record<string, unknown>[] = [];
let sharedModules: string | undefined;
for (const record of records) {
  if (record.exit !== 0) continue;
  const runRoot = archive ? join(archive,'runs',record.root.split(/[\\/]/).at(-1)) : record.root;
  const evidence = join(runRoot,'evidence');
  const json = (path: string) => JSON.parse(readFileSync(join(evidence,path),'utf8'));
  const manifest = readManifest(json('manifest.json')), result = readResult(json('result.json')), inventory = readArtifacts(json('artifacts.json'));
  if (!result.accepted || result.evidence !== 'complete' || result.cleanup !== 'passed' || inventory.runId !== manifest.runId || result.runId !== manifest.runId) throw Error('Invalid accepted run');
  verifyArtifactInventory(evidence,inventory.files.map(file=>file.path));
  for (const file of inventory.files) {
    const bytes = readFileSync(contained(evidence,file.path));
    if (bytes.length !== file.bytes || hash(bytes) !== file.sha256) throw Error(`Changed artifact: ${file.path}`);
  }
  const build = json('stages/build/observations.json');
  const common = JSON.stringify(Object.entries(build.modules).filter(([name])=>!name.endsWith('/src/renderer.ts')).sort(([a],[b])=>a.localeCompare(b)));
  if (sharedModules === undefined) sharedModules = common;
  else if (common !== sharedModules) throw Error('A non-renderer build input changed between variants');
  const rendererHash = hash(build.rendererSource);
  const moduleHash = Object.entries(build.modules).find(([name])=>name.endsWith('/src/renderer.ts'))?.[1];
  if (rendererHash !== moduleHash) throw Error('Renderer snapshot and compiled module disagree');
  if (rendererHash !== hash(readFileSync(join(archive ?? folder, record.variant + '-renderer.ts'))) || rendererHash !== record.sourceSha256) throw Error('Wrong variant source');

  const cases = result.stages.filter(stage=>/^r\d+-c\d+$/.test(stage.id)).map(stage=>{
    const m = json(`stages/${stage.id}/measurements.json`);
    if (readHeader(m,'measurements').runId !== manifest.runId || m.errors.length || m.error || m.measuredVisibility !== true || m.adapter.isFallbackAdapter || m.cleanup.some((c:{status:string})=>c.status!=='passed')) throw Error('Invalid measurement');
    if (JSON.stringify(summarizeFrames(m)) !== JSON.stringify(m.summary)) throw Error('Raw summary mismatch');
    const metric = m.summary.metrics;
    const growth = m.columns.indexOf('growths');
    const before = m.samples.filter((s:number[])=>s[0]<m.begin).at(-1);
    const samples = m.samples.filter((s:number[])=>s[0]>=m.begin && s[0]<m.end);
    const quadsColumn = m.columns.indexOf('quads'), bytesColumn = m.columns.indexOf('uploadBytes');
    if (samples.some((s:number[])=>s[bytesColumn]!==48+s[quadsColumn]*56)) throw Error('Wrong active upload range');
    const query = new URLSearchParams(m.query); query.delete('detail');
    const value = { ...record, runId:manifest.runId, query:query.toString(), rendererHash, sourceRevision:manifest.provenance,
      frames:m.summary.frames, metrics:metric, metadata:m.metadata, browser:m.version, adapter:m.adapter,
      screenshotSha256:hash(readFileSync(join(evidence,'stages',stage.id,'frame.png'))),
      sampledGrowths:samples.at(-1)[growth]-(before?.[growth]??0),
      coldSamples:m.samples.slice(0,3), artifactsSha256:hash(readFileSync(join(evidence,'artifacts.json'))), environment:manifest.environment, policy:manifest.policy };
    rows.push(value);
    return value;
  });
  console.log(`${record.label}: ${cases.length} valid cases`);
}
writeFileSync(join(folder,'summary.json'),JSON.stringify(rows,null,2)+'\n');
const groups = new Map<string, typeof rows>();
for (const row of rows) {
  const key = `${row.group}/${row.diagnostic?'stages':'clean'}/${row.query}`;
  groups.set(key,[...(groups.get(key)??[]),row]);
}
for (const [key, values] of groups) {
  const compact = values.map((r:any)=>({pair:r.pair,variant:r.variant,cpu:r.metrics.cpu.mean,prepare:r.metrics.prepare.mean,sort:r.metrics.sort?.mean,p95cpu:r.metrics.cpu.p95,p99cpu:r.metrics.cpu.p99,p95cadence:r.metrics.cadence.p95,p99cadence:r.metrics.cadence.p99}));
  console.log(JSON.stringify({key,values:compact}));
}
