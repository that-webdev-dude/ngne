import { spawnSync } from 'node:child_process';
import { appendFileSync, readFileSync, writeFileSync, openSync, closeSync, existsSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const folder=dirname(fileURLToPath(import.meta.url));
const [group='core',startArg='0',endArg='1',attempt='']=process.argv.slice(2);
if(!/^[a-z0-9-]*$/.test(attempt))throw Error('Invalid attempt suffix');
const start=Number(startArg), end=Number(endArg);
if(!['core','stages','controls'].includes(group)||![start,end].every(Number.isInteger)||start<0||end>9||end<=start)throw Error('Invalid group/step range');
const order=(count,mode='shuffled',extra='')=>`workload=ordering&count=${count}&order=${mode}&detail=0${extra}`;
const core=[order(64000),order(128000),order(64000,'ordered','&keys=late-depth')];
const controls=[order(64000,'ordered'),order(128000,'ordered'),'workload=chaos&detail=0',order(16384),order(64000,'ordered','&keys=late-depth-down'),order(64000,'ordered','&keys=wide-layers'),order(64000,'shuffled','&keys=mixed-depth')];
const schedules=[['original','current','revised'],['current','revised','original'],['revised','original','current']];
const sha=b=>createHash('sha256').update(b).digest('hex');
const expectedRevised=sha(readFileSync(join(folder,'revised-renderer.ts')));
mkdirSync(resolve('out/task-temp'),{recursive:true});
for(let step=start;step<end;step++){
  if(sha(readFileSync('src/renderer.ts'))!==expectedRevised)throw Error('Working candidate changed during comparison');
  const pair=Math.floor(step/3)+1, variant=schedules[pair-1][step%3], diagnostic=group==='stages';
  const label=`${group}-r${pair}-${variant}${attempt?'-'+attempt:''}`, logPath=join(folder,`${label}.log`);
  if(existsSync(logPath))throw Error('Refuse to overwrite retained attempt');
  const cases=[...(group==='controls'?controls:core)];
  if(pair===2)cases.reverse();
  const env={...process.env,TEMP:resolve('out/task-temp'),TMP:resolve('out/task-temp'),NGNE_MINIFY:'1',NGNE_NO_BACKGROUNDING:'1',NGNE_DIAGNOSTICS:'0',NGNE_PREPARATION_STAGES:diagnostic?'1':'0',NGNE_WARMUP_SECONDS:group==='controls'?'2':'5',NGNE_DURATION_SECONDS:group==='controls'?'4':'10',NGNE_COMPARISON_LABEL:label,NGNE_FRAME_SOURCE:join(folder,`${variant}-renderer.ts`)};
  const started=new Date().toISOString(), sourceSha256=sha(readFileSync(env.NGNE_FRAME_SOURCE));
  appendFileSync(join(folder,'attempts.jsonl'),JSON.stringify({label,step,started,sourceSha256})+'\n');
  console.log(`START ${label} ${started}`);
  const descriptor=openSync(logPath,'wx');
  let result;
  try{result=spawnSync(process.execPath,['node_modules/tsx/dist/cli.mjs','tooling/suites/benchmarks/rendering/investigate.ts','.', 'tooling/suites/benchmarks/rendering/browser/index.html',cases.join(';'),'1'],{env,stdio:['ignore',descriptor,descriptor],windowsHide:true});}
  finally{closeSync(descriptor);}
  const log=readFileSync(logPath,'utf8'), root=log.split(/\r?\n/).find(line=>/^[A-Z]:\\.*performance-investigation-/.test(line));
  const record={label,group,pair,variant,diagnostic,started,ended:new Date().toISOString(),exit:result.status,root,sourceSha256,error:String(result.error??'')};
  appendFileSync(join(folder,'runs.jsonl'),JSON.stringify(record)+'\n');
  console.log(JSON.stringify(record));
  if(result.status!==0||!root)throw Error(`Failed attempt ${label}`);
  const outcome=JSON.parse(readFileSync(join(root,'evidence/result.json'),'utf8'));
  if(!outcome.accepted||outcome.cleanup!=='passed')throw Error('Unaccepted evidence');
}
