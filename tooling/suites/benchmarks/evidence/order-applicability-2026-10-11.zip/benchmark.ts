import { execSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { cpus, release, totalmem } from "node:os";
import { performance } from "node:perf_hooks";

import { World, type SchemaComponentView } from "../../../../src/ecs.js";
import { component, f64, Game, Frame } from "../../../../src/index.js";
import { arena, type Progress, type ProgressCommand } from "../../../../demo/game.js";
const ECS_ENTITIES = 20000,
    ECS_WARMUP = 100,
    ECS_SAMPLES = 300,
    CHAOS_SEED = "bench",
    CHAOS_TICKS = 900,
    CHAOS_WARMUP = 101,
    GRID_CELLS = 260,
    GRID_TARGETS = 256,
    GRID_PROBES = 512,
    GRID_BATCHES = 64,
    GRID_WARMUP = 100,
    GRID_SAMPLES = 300,
    TICK_BUDGET_MS = 1000 / 60;
const p = component("position", { x: f64(), y: f64() }),
    v = component("velocity", { x: f64(1), y: f64(2) });
const world = new World(),
    q = world.query(p, v);
for (let i = 0; i < ECS_ENTITIES; i++) world.spawn(p.of(), v.of());
world.commit();
if (world.size !== ECS_ENTITIES) throw new Error("ECS benchmark entity count mismatch");
for (let i = 0; i < ECS_WARMUP; i++)
    q.eachChunk((chunk) => {
        const position = chunk.views.position;
        const velocity = chunk.views.velocity;
        for (let row = 0; row < chunk.count; row++) {
            position.x[row] += velocity.x[row];
            position.y[row] += velocity.y[row];
        }
    });
const samples: number[] = [];
for (let i = 0; i < ECS_SAMPLES; i++) {
    const start = performance.now();
    q.eachChunk((chunk) => {
        const position = chunk.views.position;
        const velocity = chunk.views.velocity;
        for (let row = 0; row < chunk.count; row++) {
            position.x[row] += velocity.x[row];
            position.y[row] += velocity.y[row];
        }
    });
    samples.push(performance.now() - start);
}
const g = new Game<Progress, ProgressCommand>({
    seed: CHAOS_SEED,
    state: { best: 0, runs: 0, victories: 0, lastScore: 0 },
    transition: (s) => s,
});
await g.start(await g.prepare(arena({ stress: true }), { key: "chaos" }));
const frame = new Frame();
const full: number[] = [];
const orderSamples: { tick: number; quads: number; firstReorderedIndex: number }[] = [];
let peak = 0;
for (let i = 0; i < CHAOS_TICKS; i++) {
    const start = performance.now();
    g.tick();
    frame.reset();
    g.render(frame, 0.5);
    frame.sort();
    const time = performance.now() - start;
    // Observe canonical output without changing the scene or accessing private sort keys.
    // Packing starts with identity order, so any moved index requires sort/gather.
    // Keep this applicability scan outside the existing timed interval.
    orderSamples.push({
        tick: i + 1,
        quads: frame.count,
        firstReorderedIndex: frame.order.findIndex((index, position) => index !== position),
    });
    if (i >= CHAOS_WARMUP) full.push(time);
    peak = Math.max(peak, frame.count);
}
const grid = runCollisionGridBenchmark();
const epoch = runEpochTraversalBenchmark();
const smallQueries = runSmallQueriesBenchmark();
console.log(
    JSON.stringify(
        {
            revision: revision(),
            environment: {
                node: process.version,
                platform: process.platform,
                osRelease: release(),
                arch: process.arch,
                cpu: cpus()[0]?.model.trim(),
                logicalCores: cpus().length,
                memoryGiB: Math.round(totalmem() / 2 ** 30),
            },
            ecs: {
                entities: world.size,
                warmupIterations: ECS_WARMUP,
                sampledIterations: ECS_SAMPLES,
                ms: summarize(samples),
                rawMs: samples,
            },
            chaos: {
                seed: CHAOS_SEED,
                ticks: CHAOS_TICKS,
                warmupTicks: CHAOS_WARMUP,
                sampledTicks: full.length,
                peakSprites: peak,
                peakEntitySlots: g.scenes[0].entityCapacity,
                simulationAndPreparationMs: summarize(full),
                rawMs: full,
                tickBudgetMs: TICK_BUDGET_MS,
                ticksOverBudget: full.filter((time) => time > TICK_BUDGET_MS).length,
                submissionOrder: {
                    criterion: "Canonical sorted active order is identity (order[i] === i)",
                    instrumentation:
                        "After the timed interval; CPU applicability, not browser performance",
                    allFrames: summarizeOrder(orderSamples),
                    postWarmupFrames: summarizeOrder(orderSamples.slice(CHAOS_WARMUP)),
                    raw: orderSamples,
                },
            },
            collisionGrid: grid.result,
            epochTraversal: epoch,
            manySmallQueries: smallQueries,
            target: "internal-source-microbenchmark",
            note: "CPU only. Excludes GPU submission, browser display, and input polling. Dropped ticks are a browser host-loop measure; ticksOverBudget counts sampled ticks whose CPU time exceeded one 60 Hz step.",
        },
        null,
        2,
    ),
);
g.dispose();
world.dispose();
grid.dispose();

function summarizeOrder(samples: typeof orderSamples) {
    const eligible = samples.filter((sample) => sample.firstReorderedIndex === -1);
    const sizes = (frames: typeof orderSamples) =>
        frames.length
            ? {
                  min: Math.min(...frames.map((s) => s.quads)),
                  max: Math.max(...frames.map((s) => s.quads)),
              }
            : null;
    return {
        frames: samples.length,
        eligibleFrames: eligible.length,
        eligibleFraction: eligible.length / samples.length,
        quads: sizes(samples),
        eligibleQuads: sizes(eligible),
    };
}

function runCollisionGridBenchmark() {
    const GridPosition = component("benchmark-grid-position", { x: f64(), y: f64() });
    type GridPositionView = SchemaComponentView<typeof GridPosition.fields>;
    interface SchemaEntry {
        readonly position: GridPositionView;
        readonly row: number;
    }
    const schemaWorld = new World();
    for (let target = 0; target < GRID_TARGETS; target++)
        schemaWorld.spawn(GridPosition.of({ x: target, y: target * 2 }));
    schemaWorld.commit();
    const schema = Array.from({ length: GRID_CELLS }, () => [] as SchemaEntry[]);
    const schemaPositions = schemaWorld.query(GridPosition);

    const probeCells = Array.from({ length: GRID_PROBES }, (_, probe) => probe % GRID_CELLS);
    const sample = (probe: () => number): { samples: number[]; checks: number } => {
        for (let warmup = 0; warmup < GRID_WARMUP; warmup++) probe();
        const samples: number[] = [];
        let checks = 0;
        for (let index = 0; index < GRID_SAMPLES; index++) {
            const start = performance.now();
            checks = probe();
            samples.push(performance.now() - start);
        }
        return { samples, checks };
    };
    const schemaSample = sample(() => {
        let checks = 0;
        let checksum = 0;
        for (let batch = 0; batch < GRID_BATCHES; batch++) {
            for (const cell of schema) cell.length = 0;
            schemaPositions.eachChunk((chunk) => {
                const position = chunk.views["benchmark-grid-position"];
                for (let row = 0; row < chunk.count; row++)
                    schema[position.x[row]].push({ position, row });
            });
            for (const cell of probeCells)
                for (const entry of schema[cell]) {
                    checksum += entry.position.x[entry.row] + entry.position.y[entry.row];
                    checks++;
                }
        }
        if (checksum === 0) throw new Error("Schema collision-grid benchmark was not evaluated");
        return checks;
    });
    const timerResolutionMs = measureTimerResolution();
    const schemaMs = summarize(schemaSample.samples);
    const valid = schemaMs.p50 >= timerResolutionMs * 100;
    return {
        result: {
            cells: GRID_CELLS,
            targets: GRID_TARGETS,
            probes: GRID_PROBES,
            batchesPerSample: GRID_BATCHES,
            warmupIterations: GRID_WARMUP,
            sampledIterations: GRID_SAMPLES,
            candidateChecksPerSample: schemaSample.checks,
            timerResolutionMs,
            validityThresholdMs: timerResolutionMs * 100,
            valid,
            schemaViewRow: {
                ms: schemaMs,
                rawMs: schemaSample.samples,
                nsPerCandidateCheck: summarize(
                    schemaSample.samples.map((time) => (time * 1_000_000) / schemaSample.checks),
                ),
            },
        },
        dispose: () => schemaWorld.dispose(),
    };
}

/**
 * Pairs the first typed traversal after a commit, which rebuilds borrowed chunk descriptors
 * for the new epoch, with an identical second traversal in the same epoch. The preceding commit
 * changes no membership but still advances the epoch; it is timed separately from both
 * traversals. Runs after the other sections so it cannot change their warm state.
 */
function runEpochTraversalBenchmark(
    epochWorld = world,
    traverse = () =>
        q.eachChunk((chunk) => {
            const position = chunk.views.position;
            const velocity = chunk.views.velocity;
            for (let row = 0; row < chunk.count; row++) {
                position.x[row] += velocity.x[row];
                position.y[row] += velocity.y[row];
            }
        }),
    batchesPerSample = 1,
) {
    const sample = (record?: { commit: number[]; first: number[]; second: number[] }) => {
        let commit = 0,
            first = 0,
            second = 0;
        for (let batch = 0; batch < batchesPerSample; batch++) {
            const epochBefore = epochWorld.commitEpoch;
            let start = performance.now();
            epochWorld.commit();
            commit += performance.now() - start;
            if (epochWorld.commitEpoch === epochBefore)
                throw new Error("No-op commit did not advance the query borrow epoch");
            start = performance.now();
            traverse();
            first += performance.now() - start;
            start = performance.now();
            traverse();
            second += performance.now() - start;
        }
        record?.commit.push(commit);
        record?.first.push(first);
        record?.second.push(second);
    };
    for (let i = 0; i < ECS_WARMUP; i++) sample();
    const samples = { commit: [] as number[], first: [] as number[], second: [] as number[] };
    for (let i = 0; i < ECS_SAMPLES; i++) sample(samples);
    let chunks = 0;
    // Count physical chunks independently of query sharing.
    for (const archetype of epochWorld.archetypeList) chunks += archetype.chunks.length;
    const perTick = (values: number[]) => values.map((time) => time / batchesPerSample);
    return {
        entities: epochWorld.size,
        chunks,
        batchesPerSample,
        timerResolutionMs: measureTimerResolution(),
        warmupIterations: ECS_WARMUP,
        sampledIterations: ECS_SAMPLES,
        // Raw samples are batch sums; summaries are milliseconds per simulated tick.
        rawMs: samples,
        noOpCommitMs: summarize(perTick(samples.commit)),
        firstTraversalAfterCommitMs: summarize(perTick(samples.first)),
        secondTraversalSameEpochMs: summarize(perTick(samples.second)),
        pairedDeltaMs: summarize(
            perTick(samples.first.map((first, i) => first - samples.second[i])),
        ),
        simulatedTickMs: summarize(
            perTick(samples.first.map((first, i) => first + samples.second[i] + samples.commit[i])),
        ),
    };
}

function runSmallQueriesBenchmark() {
    const smallWorld = new World();
    const systems = Array.from({ length: 12 }, (_, system) => {
        const State = component(`small-state-${system}`, {
            x: f64(),
            y: f64(),
            dx: f64(1),
            dy: f64(2),
            age: f64(),
            energy: f64(100),
            weight: f64(1),
            speed: f64(1),
        });
        for (let row = 0; row < 16; row++) smallWorld.spawn(State.of());
        const query = smallWorld.query(State);
        return () =>
            query.eachChunk((chunk) => {
                const state = chunk.views[State.name];
                for (let row = 0; row < chunk.count; row++) {
                    state.x[row] += state.dx[row] * state.speed[row];
                    state.y[row] += state.dy[row] * state.speed[row];
                    state.age[row]++;
                    state.energy[row] -= state.weight[row] * 0.001;
                }
            });
    });
    smallWorld.commit();
    // ponytail: repeat the same retained query, so sharing cannot count as a rebuild.
    const traverse = () => {
        for (const system of systems) system();
        systems[0]();
    };
    try {
        return {
            uniqueQueries: systems.length,
            traversalsPerPass: systems.length + 1,
            entitiesPerQuery: 16,
            fieldsPerComponent: 8,
            ...runEpochTraversalBenchmark(smallWorld, traverse, 16),
        };
    } finally {
        smallWorld.dispose();
    }
}

function measureTimerResolution(): number {
    let minimum = Infinity;
    let previous = performance.now();
    for (let sample = 0; sample < 10000; sample++) {
        const current = performance.now();
        const delta = current - previous;
        if (delta > 0) minimum = Math.min(minimum, delta);
        previous = current;
    }
    if (!Number.isFinite(minimum)) throw new Error("Unable to measure timer resolution");
    return minimum;
}
function summarize(values: readonly number[]) {
    const sorted = [...values].sort((a, b) => a - b);
    const at = (fraction: number) =>
        sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * fraction))];
    return {
        min: sorted[0],
        p50: at(0.5),
        p90: at(0.9),
        p95: at(0.95),
        p99: at(0.99),
        max: sorted[sorted.length - 1],
        mean: sorted.reduce((sum, value) => sum + value, 0) / sorted.length,
    };
}
function revision() {
    if (existsSync("EXPORT_REVISION")) return readFileSync("EXPORT_REVISION", "utf8").trim();
    try {
        return execSync("git rev-parse --short HEAD", { encoding: "utf8" }).trim();
    } catch {
        return "unknown";
    }
}
