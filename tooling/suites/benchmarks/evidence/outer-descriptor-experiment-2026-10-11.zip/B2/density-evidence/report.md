# ecs-density

Run: 2026-10-11T15-53-08.061Z-ecs-density-15f00df2-5044-4557-8a65-eeb9b062f36f
Accepted: false

- scenario: EPERM: operation not permitted, rename 'C:\Users\jfabi\Documents\Projects\tests\ngne\out\runs\2026-10-11T15-53-08.061Z-ecs-density-15f00df2-5044-4557-8a65-eeb9b062f36f\evidence\manifest.json.ccfd8a0d-a249-4b12-92c8-a087a64a3f45.tmp' -> 'C:\Users\jfabi\Documents\Projects\tests\ngne\out\runs\2026-10-11T15-53-08.061Z-ecs-density-15f00df2-5044-4557-8a65-eeb9b062f36f\evidence\manifest.json'

Execution: failed; correctness: not evaluated; budgets: not evaluated; cleanup: passed; evidence: complete.

Evidence applies only to the selected suite and recorded environment. It does not establish controlled run comparability or manual visual/audio confirmation. Compatibility was not selected.

- n8000-traversal: completed, correctness passed, budgets not evaluated
- n8000-arithmetic: completed, correctness passed, budgets not evaluated
- n24000-traversal: completed, correctness passed, budgets not evaluated
- n24000-arithmetic: completed, correctness passed, budgets not evaluated
- n64000-traversal: completed, correctness passed, budgets not evaluated
- n64000-arithmetic: running, correctness not evaluated, budgets not evaluated

[Manifest](manifest.json) · [Result](result.json)
