# ecs-density

Run: 2026-10-11T15-52-58.132Z-ecs-density-681eb76a-8b98-4870-8502-93465ec03197
Accepted: true


Execution: completed; correctness: passed; budgets: not evaluated; cleanup: passed; evidence: complete.

Evidence applies only to the selected suite and recorded environment. It does not establish controlled run comparability or manual visual/audio confirmation. Compatibility was not selected.

- n8000-traversal: completed, correctness passed, budgets not evaluated
- n8000-arithmetic: completed, correctness passed, budgets not evaluated
- n24000-traversal: completed, correctness passed, budgets not evaluated
- n24000-arithmetic: completed, correctness passed, budgets not evaluated
- n64000-traversal: completed, correctness passed, budgets not evaluated
- n64000-arithmetic: completed, correctness passed, budgets not evaluated
- n128000-traversal: completed, correctness passed, budgets not evaluated
- n128000-arithmetic: completed, correctness passed, budgets not evaluated

[Manifest](manifest.json) · [Result](result.json)
