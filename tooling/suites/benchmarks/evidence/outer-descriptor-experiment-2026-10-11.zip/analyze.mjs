import { readFileSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
const root = resolve('out/outer-descriptor-experiment-2026-10-11');
const read = p => JSON.parse(readFileSync(join(root, p), 'utf8'));
const median = values => [...values].sort((a,b) => a-b)[Math.floor(values.length / 2)];
const sets = {};
for (const label of ['B1','C1','C2','B2','B3','C3']) {
    const metrics = sets[label] = {};
    for (const count of [8000,24000,64000,128000]) for (const mode of ['traversal','arithmetic']) {
        const name = `n${count}-${mode}`;
        const data = read(`${label==='B2'?'B2-replacement':label}/density-evidence/stages/${name}/measurements.json`);
        for (const [i, column] of data.columns.entries()) metrics[`density.${name}.${column}`] = median(data.samples.map(row => row[i]));
    }
    const cpu = read(`${label}/benchmark.stdout.txt`);
    metrics['cpu.ecs'] = cpu.ecs.ms.p50;
    metrics['cpu.chaos'] = cpu.chaos.simulationAndPreparationMs.p50;
    metrics['cpu.collisionGrid'] = cpu.collisionGrid.schemaViewRow.ms.p50;
    for (const name of ['epochTraversal','manySmallQueries']) for (const key of ['noOpCommitMs','firstTraversalAfterCommitMs','secondTraversalSameEpochMs','pairedDeltaMs','simulatedTickMs']) metrics[`cpu.${name}.${key}`] = cpu[name][key].p50;
}
const metrics = {};
for (const key of Object.keys(sets.B1)) {
    const baseline = [1,2,3].map(i => sets[`B${i}`][key]);
    const candidate = [1,2,3].map(i => sets[`C${i}`][key]);
    const summary = values => ({ values, median: median(values), min: Math.min(...values), max: Math.max(...values), range: Math.max(...values) - Math.min(...values) });
    const b = summary(baseline), c = summary(candidate);
    const improvement = b.median-c.median;
    const deltas = baseline.map((x,i) => ({ pair:i+1, baseline:x, candidate:candidate[i], candidateMinusBaseline:candidate[i]-x, improvementPercent:(x-candidate[i])/x*100 }));
    const clearlyFaster = deltas.every(d => d.candidateMinusBaseline<0) && c.max<b.min && improvement>b.range && improvement>c.range;
    const demonstratedRegression = deltas.every(d => d.candidateMinusBaseline>0) && c.min>b.max && -improvement>b.range && -improvement>c.range;
    metrics[key] = { baseline:b, candidate:c, improvementMs:improvement, improvementPercent:improvement/b.median*100, pairs:deltas, clearlyFaster, demonstratedRegression };
}
const primary = 'density.n128000-traversal.first';
const regressions = Object.entries(metrics).filter(([key,value]) => key!==primary && value.demonstratedRegression).map(([key])=>key);
const retain = metrics[primary].clearlyFaster && regressions.length===0;
const summary = { plan:read('plan.json'), runs:read('runs.json'), recovery:{excluded:'B2 density failed with EPERM renaming evidence manifest',replacement:'B2-replacement density, 13th and final launch',note:'One authorized environmental recovery; original failed output preserved, no successful sample discarded. Pair 2 density is no longer adjacent in actual run order.'}, primary, primaryPassed:metrics[primary].clearlyFaster, demonstratedControlRegressions:regressions, decision:retain?'retain':'revert', reason:retain?'Primary gate passed with no demonstrated control regressions':'Clear improvement gate failed or control regression demonstrated; conservative rejection', metrics, limits:['Three fresh processes per variant on one Windows/Node host; p50 run ranges are descriptive, not statistical confidence intervals.','Clean internal-source CPU workloads; no allocation, installed-package, consumer FPS, browser or GPU performance claim.','Existing density stage raw samples and CPU raw samples retained unchanged.','No profiling or NGNE_DIAGNOSTICS during timings; runners unmodified.'], restoration:read('restoration.json') };
writeFileSync(join(root,'summary.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify({ decision:summary.decision, primary:metrics[primary], regressions },null,2));
