import { readFileSync, writeFileSync, readdirSync, statSync, cpSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { join, resolve, relative } from 'node:path';
const root=resolve('out/outer-descriptor-experiment-2026-10-11');
const hash=b=>createHash('sha256').update(b).digest('hex');
const read=p=>JSON.parse(readFileSync(p,'utf8'));
const summary=read(join(root,'summary.json'));
const verificationRoots=process.argv.slice(2);
summary.verification=verificationRoots.map((path,i)=>{
    const evidence=join(resolve(path),'evidence');
    const result=read(join(evidence,'result.json'));
    cpSync(evidence,join(root,`verification-${i+1}-evidence`),{recursive:true,errorOnExist:true});
    return {originalEvidence:evidence,result,command:'NGNE_WEBGPU_ADAPTER=swiftshader npm.cmd run verify:engine'};
});
summary.focusedVerification={command:'node --import tsx --test tests/ecs-soa.test.ts tests/ownership.test.ts',exitCode:0,tests:21,passed:21,failed:0};
summary.additionalChecks={
    restricted:read(join(root,'remaining-checks.json')),
    buildRecovery:{commands:['npm.cmd run build','npm.cmd run build:browser'],exitCodes:[0,0],reason:'Restricted Vite build failed EPERM realpath existing examples/hello/spark.png; both escalated builds passed.'},
    manual:read(join(root,'manual-verification.json')),
    compositeAccepted:false,
    note:'Neither verify:engine composition passed. Individual stage and serial-test coverage is recorded separately, not relabeled as a passed composition.',
};
summary.additionalChecks.browserRecovery=read(join(root,'browser-recovery.json'));
summary.additionalChecks.serialInitial={tests:337,pass:328,fail:3,skipped:6,reason:'Direct node invocation omitted npm_execpath. Three tooling tests requiring npm CLI context failed; no engine assertion failed. Complete logs retained.'};
summary.additionalChecks.npmContextRecovery=read(join(root,'npm-context-recovery.json'));
const browser=read(join(root,'manual-browser/results.json'));
summary.additionalChecks.browser={status:browser.status,renderer:browser.renderer,passed:browser.passed.length,failures:browser.failures,skipped:browser.skippedAsUnsupported,cleanup:browser.cleanup,browserVersion:browser.browserVersion};
summary.individualEvidence=[];
for(const [name,path] of [['transport','out/runs/2026-10-11T16-02-05.768Z-browser-transport-daca95a0-626f-4b52-9d30-917eec22831e/evidence'],['installed','out/runs/2026-10-11T16-02-17.526Z-installed-7917793f-6bea-44e6-9933-1e59f4049609/evidence']]){
    cpSync(path,join(root,`manual-${name}-evidence`),{recursive:true,errorOnExist:true});
    summary.individualEvidence.push({stage:name,originalEvidence:resolve(path),result:read(join(path,'result.json'))});
}
summary.controlCaveats=['Ordinary ECS median worsened 2.41%, with all three pairs slower; overlapping run ranges and improvement smaller than spread mean the predeclared demonstrated-regression gate was not met. This does not prove no regression.','128K arithmetic baseline B3 was 2.3432 ms versus 1.0166/1.0714 ms in other baseline processes; arithmetic improvement is inconclusive under the spread rule.'];
summary.finalSourceHash=hash(readFileSync('src/ecs.ts'));
if(summary.finalSourceHash!==summary.plan.candidateHash) throw Error('Final source differs from measured candidate');
summary.finalHarnessHashes=Object.fromEntries(['density','benchmark'].map(name=>[name,hash(readFileSync(`tooling/suites/benchmarks/cpu/${name}.ts`))]));
for(const [name,value] of Object.entries(summary.finalHarnessHashes))if(value!==summary.plan.harnessHashes[name])throw Error('Benchmark runner changed');
summary.environment=read(join(root,'C1/benchmark.stdout.txt')).environment;
summary.changedPaths=['src/ecs.ts','tests/ecs-soa.test.ts'];
summary.finalState='Candidate retained without commit or push; original baseline and candidate preserved.';
summary.finalizedAt=new Date().toISOString();
summary.cleanup={measurementProcessesExited:read(join(root,'restoration.json')).measurementProcessesExited,measurementLaunches:13,verification:summary.verification.map(v=>({evidence:v.originalEvidence,cleanup:v.result.cleanup,records:v.result.cleanupRecords}))};
writeFileSync(join(root,'candidate.patch'),execFileSync('git',['diff','--','src/ecs.ts','tests/ecs-soa.test.ts']));
writeFileSync(join(root,'final-git-status.txt'),execFileSync('git',['status','--short']));
writeFileSync(join(root,'summary.json'),JSON.stringify(summary,null,2));
const inventory=[];
const excludedWork=resolve(root,'manual-preparation/work');
const visit=dir=>{for(const entry of readdirSync(dir,{withFileTypes:true})){const path=join(dir,entry.name);if(path===excludedWork)continue;if(entry.isDirectory())visit(path);else if(entry.isFile() && entry.name!=='hash-inventory.json'){const bytes=readFileSync(path);inventory.push({path:relative(root,path).replaceAll('\\','/'),bytes:bytes.length,sha256:hash(bytes)});}}};
visit(root);
writeFileSync(join(root,'hash-inventory.json'),JSON.stringify({algorithm:'sha256',excludes:['hash-inventory.json','manual-preparation/work/**'],files:inventory},null,2));
console.log(JSON.stringify({decision:summary.decision,sourceHash:summary.finalSourceHash,verification:summary.verification.map(v=>({accepted:v.result.accepted,cleanup:v.result.cleanup})),files:inventory.length},null,2));
