import { readFileSync, writeFileSync, mkdirSync, cpSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { resolve, join } from 'node:path';
const root = resolve('out/outer-descriptor-experiment-2026-10-11');
const source = resolve('src/ecs.ts');
const hash = b => createHash('sha256').update(b).digest('hex');
const read = name => JSON.parse(readFileSync(join(root,name),'utf8'));
const plan = read('plan.json');
const baseline = readFileSync(join(root,'baseline-ecs.ts'));
const candidate = readFileSync(join(root,'candidate-ecs.ts'));
let expected = plan.baselineHash;
if (hash(readFileSync(source))!==expected) throw Error('Unexpected source');
const records = read('runs.json');
if (records.length!==7 || records.at(-1).label!=='B2' || records.at(-1).runner!=='density') throw Error('Unexpected completed sequence');
const failedOutcome = JSON.parse(readFileSync(join(root,'B2/density.stdout.txt'),'utf8').trim().split(/\r?\n/).at(-1));
cpSync(failedOutcome.evidence,join(root,'B2/density-evidence'),{ recursive:true, errorOnExist:true });
records.at(-1).originalEvidence = failedOutcome.evidence;
const env = {...process.env};
delete env.NGNE_DIAGNOSTICS;
delete env.NODE_OPTIONS;
const change = bytes => {
    if(hash(readFileSync(source))!==expected) throw Error('Independent source change; refusing overwrite');
    writeFileSync(source,bytes); expected=hash(bytes);
};
try {
    for(const [label,runner] of [['B2','benchmark'],['B3','density'],['B3','benchmark'],['C3','density'],['C3','benchmark']]) {
        change(label.startsWith('B')?baseline:candidate);
        const dir=join(root,label); mkdirSync(dir,{recursive:true});
        const args=['--import','tsx',`tooling/suites/benchmarks/cpu/${runner}.ts`];
        const beganAt=new Date().toISOString(); console.log(`${beganAt} START ${label} ${runner}`);
        const result=spawnSync(process.execPath,args,{cwd:process.cwd(),env,encoding:'utf8',maxBuffer:20*1024*1024,timeout:180000,windowsHide:true});
        writeFileSync(join(dir,`${runner}.stdout.txt`),result.stdout??'',{flag:'wx'});
        writeFileSync(join(dir,`${runner}.stderr.txt`),result.stderr??'',{flag:'wx'});
        const record={label,runner,command:[process.execPath,...args],beganAt,endedAt:new Date().toISOString(),status:result.status,signal:result.signal,error:result.error?.message,sourceHash:expected};
        records.push(record);
        writeFileSync(join(root,'runs.json'),JSON.stringify(records,null,2));
        if(hash(readFileSync(source))!==expected) throw Error('Independent source change during measurement');
        if(runner==='density' && result.stdout?.trim()) {
            const outcome=JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1));
            cpSync(outcome.evidence,join(dir,'density-evidence'),{recursive:true,errorOnExist:true});
            record.originalEvidence=outcome.evidence;
            writeFileSync(join(root,'runs.json'),JSON.stringify(records,null,2));
        }
        console.log(`${record.endedAt} END ${label} ${runner} status=${result.status}`);
    }
} finally {
    change(baseline);
    writeFileSync(join(root,'restoration.json'),JSON.stringify({restoredAt:new Date().toISOString(),hash:hash(readFileSync(source)),reason:'Reverted: missing complete baseline replicate after B2 evidence publication failure',measurementProcessesExited:records.every(x=>x.status!==null),processesAttempted:records.length,successfulProcesses:records.filter(x=>x.status===0).length},null,2));
}
