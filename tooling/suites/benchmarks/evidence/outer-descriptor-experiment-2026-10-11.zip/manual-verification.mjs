import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { spawnSync, execFileSync } from 'node:child_process';
import { resolve, join } from 'node:path';
const root=resolve('out/outer-descriptor-experiment-2026-10-11');
const npm=join(process.execPath,'../node_modules/npm/bin/npm-cli.js');
const preparation=join(root,'manual-preparation');
const manifest=join(preparation,'evidence/manifest.json');
const steps=[
    ['prepare',[npm,'run','prepare:package','--','--output',preparation]],
    ['prepared',[npm,'run','check:prepared','--','--manifest',manifest]],
    ['transport',[npm,'run','check:browser-transport']],
    ['installed',[npm,'run','verify:installed','--','--manifest',manifest]],
    ['browser',[npm,'run','test:browser']],
];
const env={...process.env,NGNE_WEBGPU_ADAPTER:'swiftshader',NGNE_BROWSER_ARTIFACT_DIR:join(root,'manual-browser')};
delete env.NGNE_DIAGNOSTICS; delete env.NODE_OPTIONS;
const records=[];
for(const [stage,args] of steps){
    if(['prepared','installed'].includes(stage) && records.find(r=>r.stage==='prepare')?.exitCode!==0){records.push({stage,skipped:'package preparation failed'});continue;}
    const beganAt=new Date().toISOString();console.log(`${beganAt} START ${stage}`);
    const result=spawnSync(process.execPath,args,{env,encoding:'utf8',maxBuffer:32*1024*1024,timeout:240000,windowsHide:true});
    writeFileSync(join(root,`manual-${stage}.stdout.txt`),result.stdout??'');
    writeFileSync(join(root,`manual-${stage}.stderr.txt`),result.stderr??'');
    records.push({stage,command:[process.execPath,...args],beganAt,endedAt:new Date().toISOString(),exitCode:result.status,signal:result.signal,error:result.error?.message});
    writeFileSync(join(root,'manual-verification.json'),JSON.stringify(records,null,2));
    console.log(`${new Date().toISOString()} END ${stage} exit=${result.status}`);
    if(result.signal || result.error) throw Error('Process did not finish normally; stop to avoid overlapping verification');
}
const tests=[...readdirSync('tests').filter(x=>x.endsWith('.test.ts')).map(x=>`tests/${x}`),...readdirSync('demo/tests').filter(x=>x.endsWith('.test.ts')).map(x=>`demo/tests/${x}`),...readdirSync('examples',{withFileTypes:true}).filter(x=>x.isDirectory()).flatMap(x=>{try{return readdirSync(`examples/${x.name}/tests`).filter(y=>y.endsWith('.test.ts')).map(y=>`examples/${x.name}/tests/${y}`);}catch{return [];}}),...readdirSync('tooling/tests').filter(x=>x.endsWith('.test.ts')).map(x=>`tooling/tests/${x}`)];
const args=['--import','tsx','--test','--test-concurrency=1',...tests];
writeFileSync(join(root,'serial-test-files.json'),JSON.stringify(tests,null,2));
const beganAt=new Date().toISOString();console.log(`${beganAt} START serial-tests (${tests.length} files)`);
const result=spawnSync(process.execPath,args,{env,encoding:'utf8',maxBuffer:32*1024*1024,timeout:360000,windowsHide:true});
writeFileSync(join(root,'serial-tests.stdout.txt'),result.stdout??'');
writeFileSync(join(root,'serial-tests.stderr.txt'),result.stderr??'');
records.push({stage:'serial-tests',command:[process.execPath,...args],beganAt,endedAt:new Date().toISOString(),exitCode:result.status,signal:result.signal,error:result.error?.message});
writeFileSync(join(root,'manual-verification.json'),JSON.stringify(records,null,2));
console.log(`${new Date().toISOString()} END serial-tests exit=${result.status}`);
if(records.some(r=>r.exitCode!==0))process.exitCode=1;
