$ErrorActionPreference = 'Stop'
$taskChecks = @()
foreach ($taskCheck in @('typecheck:tooling', 'typecheck', 'build', 'build:browser')) {
    $taskLog = 'out/outer-descriptor-experiment-2026-10-11/check-' + $taskCheck.Replace(':','-') + '.log'
    & npm.cmd run $taskCheck *> $taskLog
    $taskChecks += [pscustomobject]@{ command = "npm.cmd run $taskCheck"; exitCode = $LASTEXITCODE; log = $taskLog }
    $taskChecks | ConvertTo-Json | Set-Content out/outer-descriptor-experiment-2026-10-11/remaining-checks.json
    Write-Output "$taskCheck exit $LASTEXITCODE"
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
