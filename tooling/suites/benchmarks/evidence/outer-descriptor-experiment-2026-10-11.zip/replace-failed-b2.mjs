import { readFileSync, writeFileSync, mkdirSync, cpSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { resolve, join } from 'node:path';
const root=resolve('out/outer-descriptor-experiment-2026-10-11');
const read=name=>JSON.parse(readFileSync(join(root,name),'utf8'));
const plan=read('plan.json'), records=read('runs.json');
const hash=()=>createHash('sha256').update(readFileSync('src/ecs.ts')).digest('hex');
if(records.length!==12 || hash()!==plan.baselineHash) throw Error('Unexpected state');
const directory=join(root,'B2-replacement'); mkdirSync(directory);
writeFileSync(join(directory,'authorization.json'),JSON.stringify({reason:'Exactly one replacement authorized by parent for failed B2 density evidence-file EPERM; no successful sample discarded, no further recovery launches allowed.',excludedExecution:'B2/density',actualSequencePosition:13},null,2));
const env={...process.env}; delete env.NGNE_DIAGNOSTICS; delete env.NODE_OPTIONS;
const args=['--import','tsx','tooling/suites/benchmarks/cpu/density.ts'];
const beganAt=new Date().toISOString();
const result=spawnSync(process.execPath,args,{cwd:process.cwd(),env,encoding:'utf8',maxBuffer:20*1024*1024,timeout:180000,windowsHide:true});
writeFileSync(join(directory,'density.stdout.txt'),result.stdout??'');
writeFileSync(join(directory,'density.stderr.txt'),result.stderr??'');
const record={label:'B2-replacement',replaces:'B2 density failed execution',runner:'density',command:[process.execPath,...args],beganAt,endedAt:new Date().toISOString(),status:result.status,signal:result.signal,error:result.error?.message,sourceHash:hash()};
records.push(record);
if(result.stdout?.trim()) {
    const outcome=JSON.parse(result.stdout.trim().split(/\r?\n/).at(-1));
    cpSync(outcome.evidence,join(directory,'density-evidence'),{recursive:true,errorOnExist:true});
    record.originalEvidence=outcome.evidence;
}
writeFileSync(join(root,'runs.json'),JSON.stringify(records,null,2));
writeFileSync(join(root,'restoration.json'),JSON.stringify({restoredAt:new Date().toISOString(),hash:hash(),reason:'Baseline restored pending decision; authorized one-time failed-execution replacement completed',measurementProcessesExited:records.every(x=>x.status!==null),processesAttempted:records.length,successfulProcesses:records.filter(x=>x.status===0).length},null,2));
console.log(JSON.stringify(record,null,2));
if(result.status!==0 || hash()!==plan.baselineHash) process.exitCode=1;
