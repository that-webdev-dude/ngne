import { readFileSync, writeFileSync, mkdirSync, cpSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawnSync, execFileSync } from 'node:child_process';
import { resolve, join } from 'node:path';
const root = resolve('out/outer-descriptor-experiment-2026-10-11');
const source = resolve('src/ecs.ts');
const hash = b => createHash('sha256').update(b).digest('hex');
const baseline = readFileSync(source);
const baselineHash = 'b5935cb4536a031e852acc21739f883f01358e643a07b81d40e8a2485ad685cc';
if (hash(baseline) !== baselineHash) throw Error('Unexpected baseline');
writeFileSync(join(root, 'baseline-ecs.ts'), baseline, { flag: 'wx' });
const original = baseline.toString();
const start = original.indexOf('    Object.defineProperties(descriptor, {');
const end = original.indexOf('    return Object.freeze(descriptor)', start);
if (start < 0 || end < 0) throw Error('Missing exact candidate site');
const newline = original.includes('\r\n') ? '\r\n' : '\n';
const replacement = `    Object.defineProperty(descriptor, "count", {
        get() {
            assertValid();
            return chunk.count;
        },
    });
    Object.defineProperty(descriptor, "capacity", {
        get() {
            assertValid();
            return CHUNK_CAPACITY;
        },
    });
    Object.defineProperty(descriptor, "views", {
        get() {
            assertValid();
            return views;
        },
    });
    Object.defineProperty(descriptor, "entityAt", {
        value(row: number) {
            assertValid();
            if (!Number.isInteger(row) || row < 0 || row >= chunk.count)
                throw new Error("Schema chunk row is outside the live range");
            return chunk.entities[row]!;
        },
    });
`.replaceAll('\n', newline);
const candidate = Buffer.from(original.slice(0, start) + replacement + original.slice(end));
const candidateHash = hash(candidate);
writeFileSync(join(root, 'candidate-ecs.ts'), candidate, { flag: 'wx' });
const order = ['B1', 'C1', 'C2', 'B2', 'B3', 'C3'];
const env = { ...process.env };
delete env.NGNE_DIAGNOSTICS;
delete env.NODE_OPTIONS;
const plan = {
    createdAt: new Date().toISOString(), baselineHash, candidateHash, order,
    head: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
    acceptance: 'Primary 128K traversal-only first traversal must improve in every pair, have non-overlapping fresh-process p50 ranges, and median improvement larger than both ranges. Revert on a failed primary gate or demonstrated control regression. Control regression: all pairs worse, non-overlapping p50 ranges, median worsening larger than both ranges.',
    preMeasurementAdjustment: 'Parent clarified before any measurement: 128K is the established primary target; smaller density sizes are scaling controls and need no clear gain.',
    controls: 'Other density traversal sizes; all density arithmetic/commit/sameEpoch/plain; CPU ordinary ECS/Chaos/grid, epoch and small queries first/sameEpoch/commit/simulatedTick.',
    processes: 12, diagnostics: false, nodeOptions: null, node: process.version,
    harnessHashes: Object.fromEntries(['density', 'benchmark'].map(x => [x, hash(readFileSync(`tooling/suites/benchmarks/cpu/${x}.ts`))])),
};
writeFileSync(join(root, 'plan.json'), JSON.stringify(plan, null, 2), { flag: 'wx' });
let expected = baselineHash;
const records = [];
const change = bytes => {
    if (hash(readFileSync(source)) !== expected) throw Error('Source changed independently; refusing overwrite');
    writeFileSync(source, bytes);
    expected = hash(bytes);
};
try {
    for (const label of order) {
        change(label.startsWith('B') ? baseline : candidate);
        const directory = join(root, label);
        mkdirSync(directory);
        for (const runner of ['density', 'benchmark']) {
            const args = ['--import', 'tsx', `tooling/suites/benchmarks/cpu/${runner}.ts`];
            const beganAt = new Date().toISOString();
            console.log(`${beganAt} START ${label} ${runner}`);
            const result = spawnSync(process.execPath, args, { cwd: process.cwd(), env, encoding: 'utf8', maxBuffer: 20 * 1024 * 1024, timeout: 180000, windowsHide: true });
            writeFileSync(join(directory, `${runner}.stdout.txt`), result.stdout ?? '');
            writeFileSync(join(directory, `${runner}.stderr.txt`), result.stderr ?? '');
            const record = { label, runner, command: [process.execPath, ...args], beganAt, endedAt: new Date().toISOString(), status: result.status, signal: result.signal, error: result.error?.message, sourceHash: expected };
            records.push(record);
            writeFileSync(join(root, 'runs.json'), JSON.stringify(records, null, 2));
            if (result.status !== 0) throw Error(`Failed ${label} ${runner}: ${result.stderr}`);
            if (hash(readFileSync(source)) !== expected) throw Error('Source changed during measurement');
            if (runner === 'density') {
                const lines = result.stdout.trim().split(/\r?\n/);
                const outcome = JSON.parse(lines.at(-1));
                if (!outcome.accepted) throw Error('Density not accepted');
                cpSync(outcome.evidence, join(directory, 'density-evidence'), { recursive: true, errorOnExist: true });
                record.originalEvidence = outcome.evidence;
                writeFileSync(join(root, 'runs.json'), JSON.stringify(records, null, 2));
            }
            console.log(`${record.endedAt} END ${label} ${runner}`);
        }
    }
} finally {
    change(baseline);
    writeFileSync(join(root, 'restoration.json'), JSON.stringify({ restoredAt: new Date().toISOString(), hash: hash(readFileSync(source)), reason: 'Baseline restored pending fixed decision', measurementProcessesExited: records.every(x => x.status === 0) }, null, 2));
}
