# verification

Run: 2026-10-11T15-56-07.171Z-verification-a99c3f0c-4a37-4e0c-b0d0-4eb3e06efe35
Accepted: false

- scenario: tests: command timeout
- cleanup: format terminate/verify: format PID 20144: terminate/verify failed: Command failed: powershell.exe -NoProfile -NonInteractive -Command Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,@{Name='Born';Expression={$_.CreationDate.ToUniversalTime().ToString('o')}} | ConvertTo-Json -Compress
Get-CimInstance : Access to a CIM resource was not available to the client.
At line:1 char:1
+ Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcess ...
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : NotSpecified: (:) [Get-CimInstance], CimException
    + FullyQualifiedErrorId : Microsoft.Management.Infrastructure.CimException,Microsoft.Management.Infrastructure.Cim 
   Cmdlets.GetCimInstanceCommand
 

- cleanup: tests terminate/verify: tests PID 3304: terminate/verify failed: Command failed: powershell.exe -NoProfile -NonInteractive -Command Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,@{Name='Born';Expression={$_.CreationDate.ToUniversalTime().ToString('o')}} | ConvertTo-Json -Compress
Get-CimInstance : Access to a CIM resource was not available to the client.
At line:1 char:1
+ Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcess ...
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : NotSpecified: (:) [Get-CimInstance], CimException
    + FullyQualifiedErrorId : Microsoft.Management.Infrastructure.CimException,Microsoft.Management.Infrastructure.Cim 
   Cmdlets.GetCimInstanceCommand
 


Execution: failed; correctness: failed; budgets: not evaluated; cleanup: failed; evidence: complete.

Evidence applies only to the selected suite and recorded environment. It does not establish controlled run comparability or manual visual/audio confirmation. Compatibility was not selected.

- format: completed, correctness passed, budgets not evaluated
- tests: failed, correctness failed, budgets not evaluated

[Manifest](manifest.json) · [Result](result.json)
