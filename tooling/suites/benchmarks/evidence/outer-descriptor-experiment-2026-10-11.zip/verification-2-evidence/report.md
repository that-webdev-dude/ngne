# verification

Run: 2026-10-11T15-58-47.104Z-verification-827504e0-6e18-40b6-813c-2e05c22e5038
Accepted: false

- scenario: tests: exit 5; see C:\Users\jfabi\Documents\Projects\tests\ngne\out\runs\2026-10-11T15-58-47.104Z-verification-827504e0-6e18-40b6-813c-2e05c22e5038\evidence\stages\tests\logs\command.log

Execution: failed; correctness: failed; budgets: not evaluated; cleanup: passed; evidence: complete.

Evidence applies only to the selected suite and recorded environment. It does not establish controlled run comparability or manual visual/audio confirmation. Compatibility was not selected.

- format: completed, correctness passed, budgets not evaluated
- tests: failed, correctness failed, budgets not evaluated

[Manifest](manifest.json) · [Result](result.json)
