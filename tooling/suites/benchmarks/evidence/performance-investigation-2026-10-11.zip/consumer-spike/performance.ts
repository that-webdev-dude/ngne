import { BrowserGame, type Stats } from '@ngne/core';
import { defaults, HEIGHT, SEED, WIDTH, type Simulation } from '../src/config/simulation';
import { observatory } from '../src/scenes/observatory';

const params = new URLSearchParams(location.search);
const count = Number(params.get('count') ?? 64000);
const detailed = params.get('detail') !== '0';
if (![8000, 24000, 64000, 128000].includes(count)) throw Error('Invalid load');
const controls = { ...defaults(), particles: count };
const simulation: Simulation = { time: 0, alive: 0, absorbed: 0, drawn: 0 };
const samples: number[][] = [];
const state = { ready: false, hidden: false, error: '', samples, columns: ['time', 'cadence', 'cpu', 'update', 'applicationRender', 'backend', 'sort', 'ticks', 'quads', 'dropped'], metadata: { count, detailed, seed: SEED, controls: { ...controls }, width: WIDTH, height: HEIGHT, engine: '@ngne/core@0.2.1', scope: 'Actual consumer scene with fresh state; production HUD omitted; CPU-only nested sort interval', readySimulationTime: 0 } };
Object.assign(window, { __investigation: state });
let previous = 0, applicationRender = 0, backend = 0, sortMs = 0, ticks = 0;
function afterFrame(stats: Readonly<Stats>) {
  const now = performance.now();
  if (document.hidden) state.hidden = true;
  if (simulation.alive === count) {
    if (!state.ready) state.metadata.readySimulationTime = simulation.time;
    state.ready = true;
    samples.push([now, previous ? now - previous : 0, stats.frameMs, stats.updateMs, detailed ? applicationRender : -1, detailed ? backend : -1, detailed ? sortMs : -1, ticks, stats.sprites, stats.droppedTicks]);
  }
  previous = now; ticks = 0;
  if (samples.length >= 30000) { state.error = 'Sample limit'; void app.stop(); }
}
const app = new BrowserGame<Record<string, never>, never>({ canvas: document.querySelector<HTMLCanvasElement>('canvas')!, width: WIDTH, height: HEIGHT, clear: 0x08090d, seed: SEED, state: {}, transition: state => state, maxTicks: 3, afterFrame, diagnostic: error => { if (error instanceof Error) state.error = String(error); } });
const originalTick = app.game.tick.bind(app.game);
app.game.tick = (...args: Parameters<typeof originalTick>) => { ticks++; return originalTick(...args); };
if (detailed) {
  const originalRender = app.game.render.bind(app.game);
  app.game.render = (...args: Parameters<typeof originalRender>) => { const start = performance.now(); originalRender(...args); applicationRender = performance.now() - start; };
  const originalSort = app.frame.sort.bind(app.frame);
  app.frame.sort = () => { const start = performance.now(); originalSort(); sortMs = performance.now() - start; };
}
try {
  const prepared = await app.game.prepare(observatory(controls, simulation), { key: 'observation-001' });
  await app.start(prepared);
  if (detailed) {
    const renderer = app.renderer!;
    const original = renderer.render.bind(renderer);
    renderer.render = (...args: Parameters<typeof original>) => { const start = performance.now(); original(...args); backend = performance.now() - start; };
  }
} catch (error) { state.error = String(error); }
document.addEventListener('visibilitychange', () => { if (document.hidden) state.hidden = true; });
window.addEventListener('pagehide', () => { void app.dispose(); }, { once: true });
